package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import dominio.Cliente;
import dominio.Cuenta;
import dominio.CuotasPrestamos;
import dominio.TipoCuenta;

public class CuentaDaoImpl implements CuentaDao {

	private static final String insert = "INSERT INTO cuentas(NroCuenta,DniCliente,CBU,Tipo,FechaCreacion,Saldo,Activa) VALUES(?,?,?,?,?,?,?)";
	private static final String readall = "SELECT * FROM db_banco.cuentas";

	private static final String delete = "UPDATE cuentas SET activa = ? WHERE CBU = ?";

	
	
	public boolean insert(Cuenta cuenta) {
		PreparedStatement statement;
		Connection conexion = Conexion.getConexion().getSQLConexion();
		boolean isInsertExitoso = false;
		try {
			statement = conexion.prepareStatement(insert);
			statement.setString(1, cuenta.getNroCuenta());
			statement.setString(2, cuenta.getCliente().getDni());
			statement.setString(3, cuenta.getCBU());
			statement.setString(4, String.valueOf(cuenta.getTipo().getDescripcion()));

			statement.setString(5, cuenta.getFechaCreacion());
			statement.setDouble(6, cuenta.getSaldo());
			statement.setBoolean(7, cuenta.getActiva());
			if (statement.executeUpdate() > 0) {
				conexion.commit();
				isInsertExitoso = true;
				 System.out.println("Commit exitoso");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		    System.out.println("Error al insertar en la base de datos: " + e.getMessage());
		    try {
		        conexion.rollback();
		    } catch (SQLException e1) {
		        e1.printStackTrace();
		    }
		}

		return isInsertExitoso;
	}

	@Override
	public boolean deleteLogico(String CBU) {
		PreparedStatement statement;
		Connection conexion = Conexion.getConexion().getSQLConexion();
		boolean isDeleteExitoso = false;
		try {
			statement = conexion.prepareStatement(delete);
			statement.setBoolean(1, false);
			statement.setString(2, CBU);
			if (statement.executeUpdate() > 0) {
				conexion.commit();
				isDeleteExitoso = true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
			try {
				conexion.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
		}
		return isDeleteExitoso;
	}

	@Override
	public List<Cuenta> readAll() {
		PreparedStatement statement;
		ResultSet resultSet; // Guarda el resultado de la query
		ArrayList<Cuenta> cuenta = new ArrayList<Cuenta>();
		Conexion conexion = Conexion.getConexion();
		try {
			statement = conexion.getSQLConexion().prepareStatement(readall);
			System.out.println("Consulta SQL: " + readall);
			resultSet = statement.executeQuery();
			while (resultSet.next()) {
				cuenta.add(getCuenta(resultSet));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return cuenta;
	}

	private Cuenta getCuenta(ResultSet resultSet) throws SQLException {
		String Nrocuenta = resultSet.getString("NroCuenta");
		String DniCliente = resultSet.getString("DniCliente");
		String CBU = resultSet.getString("CBU");
		String Tipo = resultSet.getString("Tipo");
		String FechaCreacion = resultSet.getString("FechaCreacion");
		double Saldo = resultSet.getDouble("Saldo");
		Boolean activa = resultSet.getBoolean("activa");
		
		ClienteDao clienteDao = new ClienteDaoImpl(); 
		 
		Cliente cliente = clienteDao.obtenerClienteXdni(DniCliente);
		
		TipoCuentaDao tipoCuentaDao = new TipoCuentaDaoImpl();
		
		TipoCuenta tipoCuenta = tipoCuentaDao.obtenerCuentaXNombre(Tipo);
		    
		return new Cuenta(Nrocuenta, cliente,CBU,tipoCuenta, FechaCreacion,Saldo, activa);
	}

	@Override
	public boolean update(Cuenta cuenta_a_modificar, int CBU) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Cuenta obtenerCuentaXCbu(String Cbu) {
	    PreparedStatement statement = null;
	    ResultSet resultSet = null;
	    Connection conexion = Conexion.getConexion().getSQLConexion();

	    try {
	        String consulta = "SELECT * FROM cuentas WHERE CBU = ?";
	        statement = conexion.prepareStatement(consulta);
	        statement.setString(1, Cbu);

	        resultSet = statement.executeQuery();

	        if (resultSet.next()) {
	        
	            String DniCliente = resultSet.getString("DniCliente");
	            String CBU = resultSet.getString("CBU"); 
	            String Tipo = resultSet.getString("Tipo");
	            String NroCuenta = resultSet.getString("NroCuenta");
	            String FechaCreacion = resultSet.getString("FechaCreacion");
	            double Saldo = resultSet.getDouble("Saldo"); 
	            boolean activa = resultSet.getBoolean("Activa"); 
	            
	            ClienteDao clienteDao = new ClienteDaoImpl(); 
	   		 
	    		Cliente cliente = clienteDao.obtenerClienteXdni(DniCliente);
	    		
	    		TipoCuentaDao tipoCuentaDao = new TipoCuentaDaoImpl();
	    		
	    		TipoCuenta tipoCuenta = tipoCuentaDao.obtenerCuentaXNombre(Tipo);
	            Cuenta cuenta = new Cuenta(NroCuenta, cliente, CBU, tipoCuenta, FechaCreacion, Saldo, activa);

	            return cuenta;
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    } finally {
	        try {
	            if (resultSet != null)
	                resultSet.close();
	            if (statement != null)
	                statement.close();
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	    }

	    return null;
	}
	
	public Cuenta obtenerCuentaXnroCuenta(String nroCuenta) {
	    PreparedStatement statement = null;
	    ResultSet resultSet = null;
	    Connection conexion = Conexion.getConexion().getSQLConexion();

	    try {
	        String consulta = "SELECT * FROM cuentas WHERE NroCuenta = ?";
	        statement = conexion.prepareStatement(consulta);
	        statement.setString(1, nroCuenta);

	        resultSet = statement.executeQuery();

	        if (resultSet.next()) {
	        
	            String DniCliente = resultSet.getString("DniCliente");
	            String CBU = resultSet.getString("CBU"); 
	            String Tipo = resultSet.getString("Tipo");
	            String NroCuenta = resultSet.getString("NroCuenta");
	            String FechaCreacion = resultSet.getString("FechaCreacion");
	            double Saldo = resultSet.getDouble("Saldo"); 
	            boolean activa = resultSet.getBoolean("Activa"); 
	            ClienteDao clienteDao = new ClienteDaoImpl(); 
		   		 
	    		Cliente cliente = clienteDao.obtenerClienteXdni(DniCliente);
	    		
	    		TipoCuentaDao tipoCuentaDao = new TipoCuentaDaoImpl();
	    		
	    		TipoCuenta tipoCuenta = tipoCuentaDao.obtenerCuentaXNombre(Tipo);
	            Cuenta cuenta = new Cuenta(NroCuenta, cliente, CBU, tipoCuenta, FechaCreacion, Saldo, activa);


	            return cuenta;
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    } finally {
	        try {
	            if (resultSet != null)
	                resultSet.close();
	            if (statement != null)
	                statement.close();
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	    }

	    return null;
	}

	public int cantidadCuentasXdni(String dni) {
		int cant = 0;

		return cant;
	}

	public List<Cuenta> listaCuentaXdni(String dni) {

		
		ArrayList<Cuenta> Listado = new ArrayList<Cuenta>();
		Connection conexion = Conexion.getConexion().getSQLConexion();

		try {
			String consulta = "SELECT * FROM db_banco.cuentas Where DniCliente = ?";
			
					
			try (PreparedStatement statement = conexion.prepareStatement(consulta)) {
                statement.setString(1, dni);

                try (ResultSet resultSet = statement.executeQuery()) {
                    while (resultSet.next()) {
                    	String DniCliente = resultSet.getString("DniCliente");
         	            String CBU = resultSet.getString("CBU"); 
         	            String Tipo = resultSet.getString("Tipo");
         	            String NroCuenta = resultSet.getString("NroCuenta");
         	            String FechaCreacion = resultSet.getString("FechaCreacion");
         	            double Saldo = resultSet.getDouble("Saldo"); 
         	            boolean activa = resultSet.getBoolean("Activa"); 
         	           ClienteDao clienteDao = new ClienteDaoImpl(); 
      		   		 
       	    		Cliente cliente = clienteDao.obtenerClienteXdni(DniCliente);
       	    		
       	    		TipoCuentaDao tipoCuentaDao = new TipoCuentaDaoImpl();
       	    		
       	    		TipoCuenta tipoCuenta = tipoCuentaDao.obtenerCuentaXNombre(Tipo);
       	            Cuenta cuenta = new Cuenta(NroCuenta, cliente, CBU, tipoCuenta, FechaCreacion, Saldo, activa);
                        
                       
                        Listado.add(cuenta);
                    }
                }
            }
        
    } catch (SQLException e) {
        e.printStackTrace();
    }

    return Listado;
}
	
	public List<Cuenta> obtenerCuentaXemail(String email) {
		

		ArrayList<Cuenta> Listado = new ArrayList<Cuenta>();
		Connection conexion = Conexion.getConexion().getSQLConexion();

		try {
			String consulta = "SELECT * FROM db_banco.cuentas Cu inner join db_banco.clientes Cl on Cu.DniCliente = Cl.Dni where Cl.Email=?";
			
					
			try (PreparedStatement statement = conexion.prepareStatement(consulta)) {
                statement.setString(1, email);

                try (ResultSet resultSet = statement.executeQuery()) {
                    while (resultSet.next()) {
                    	String DniCliente = resultSet.getString("DniCliente");
         	            String CBU = resultSet.getString("CBU"); 
         	            String Tipo = resultSet.getString("Tipo");
         	            String NroCuenta = resultSet.getString("NroCuenta");
         	            String FechaCreacion = resultSet.getString("FechaCreacion");
         	            double Saldo = resultSet.getDouble("Saldo"); 
         	            boolean activa = resultSet.getBoolean("Activa"); 
         	           ClienteDao clienteDao = new ClienteDaoImpl(); 
      		   		 
       	    		Cliente cliente = clienteDao.obtenerClienteXdni(DniCliente);
       	    		
       	    		TipoCuentaDao tipoCuentaDao = new TipoCuentaDaoImpl();
       	    		
       	    		TipoCuenta tipoCuenta = tipoCuentaDao.obtenerCuentaXNombre(Tipo);
       	            Cuenta cuenta = new Cuenta(NroCuenta, cliente, CBU, tipoCuenta, FechaCreacion, Saldo, activa);
                        
                       
                        Listado.add(cuenta);
                    }
                }
            }
        
    } catch (SQLException e) {
        e.printStackTrace();
    }
		
		return Listado;
	}

	public boolean insertImporte(String nroCuenta, double importe) {
		
		PreparedStatement statement = null;
	    Connection conexion = Conexion.getConexion().getSQLConexion();
	    boolean isInsertExitoso = false;
	    try {
	        String consulta = "UPDATE db_banco.cuentas SET Saldo = Saldo + ? WHERE NroCuenta = ?";
	        statement = conexion.prepareStatement(consulta);
	        statement.setDouble(1, importe);
	        statement.setString(2, nroCuenta);

	        if (statement.executeUpdate() > 0) {
				conexion.commit();
				isInsertExitoso = true;
	    	}

	    } catch (SQLException e) {
	        e.printStackTrace();
	        try {
	            conexion.rollback();
	        } catch (SQLException e1) {
	            e1.printStackTrace();
	        }
	    } finally {
	        try {
	            if (statement != null)
	                statement.close();
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	    }
	    return isInsertExitoso;
		
	}

	public boolean restarCuotaPrestamo(CuotasPrestamos cuotasPrestamos) {
		
		
		//double saldoActual = obtenerSaldoCuenta(cuotasPrestamos.getNroCuenta());
		
		PreparedStatement statement = null;
	    Connection conexion = Conexion.getConexion().getSQLConexion();

	    try {
	        
	       System.out.println(" nrocuenta" + cuotasPrestamos.getNroCuenta());

	        
	        //if (saldoActual >= cuotasPrestamos.getImporteFinalCuota()) {//comprueba que sea mayor
	        	
	        	
	            String consulta = "update cuentas set Saldo = Saldo - ? where NroCuenta = ?";
	            statement = conexion.prepareStatement(consulta);
	            statement.setDouble(1, cuotasPrestamos.getImporteFinalCuota());
	            statement.setString(2, cuotasPrestamos.getNroCuenta());

	            statement.executeUpdate();
	            conexion.commit();
	            return true;
//	        } else {
//	            // No hay suficiente saldo para restar la cuota manejar int?
//	        	
//	            return false;
//	        }

	    } catch (SQLException e) {
	        e.printStackTrace();
	   
	    } 
	    

	    return false;
		
	}

	public boolean debitarImporte(String nroCuenta, double monto) {
		PreparedStatement statement = null;
	    Connection conexion = Conexion.getConexion().getSQLConexion();
	    boolean isInsertExitoso = false;
	
	    try {
	        String consulta = "UPDATE db_banco.cuentas SET Saldo = Saldo - ? WHERE NroCuenta = ?";
	        statement = conexion.prepareStatement(consulta);
	        statement.setDouble(1, monto);
	        statement.setString(2, nroCuenta);

	        statement.executeUpdate();
	        conexion.commit();
	        
	    	if (statement.executeUpdate() > 0) {
				conexion.commit();
				isInsertExitoso = true;
	    	}


	    } catch (SQLException e) {
	        e.printStackTrace();
	        try {
	            conexion.rollback();
	        } catch (SQLException e1) {
	            e1.printStackTrace();
	        }
	    } finally {
	        try {
	            if (statement != null)
	                statement.close();
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	    }
		return isInsertExitoso ; 
	}

	public int traerCantidad(Cliente cliente) {

		PreparedStatement statement = null;
	    ResultSet resultSet = null;
	    Connection conexion = Conexion.getConexion().getSQLConexion();

	    try {
	        String consulta = "SELECT COUNT(*) AS cantidad FROM Cuentas WHERE DniCliente = ?";
	        statement = conexion.prepareStatement(consulta);
	        statement.setString(1, cliente.getDni());

	        resultSet = statement.executeQuery();

	        if (resultSet.next()) {
	            return resultSet.getInt("cantidad");
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    } finally {
	        try {
	            if (resultSet != null)
	                resultSet.close();
	            if (statement != null)
	                statement.close();
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	    }

	    return 0; 
		
	}

	public Cuenta traerCuentaXdni(String dni) {
		PreparedStatement statement = null;
	    ResultSet resultSet = null;
	    Connection conexion = Conexion.getConexion().getSQLConexion();

	    try {
	        String consulta = "SELECT * FROM Cuentas WHERE DniCliente = ? LIMIT 1";
	        statement = conexion.prepareStatement(consulta);
	        statement.setString(1, dni);

	        resultSet = statement.executeQuery();

	        if (resultSet.next()) {
	            String NroCuenta = resultSet.getString("NroCuenta");
	            String DniCliente = resultSet.getString("DniCliente");
	            String CBU = resultSet.getString("CBU");
	            String Tipo = resultSet.getString("Tipo");
	            String FechaCreacion = resultSet.getString("FechaCreacion");
	            double Saldo = resultSet.getDouble("Saldo");
	            boolean activa = resultSet.getBoolean("Activa");

	            ClienteDao clienteDao = new ClienteDaoImpl();
	            Cliente cliente = clienteDao.obtenerClienteXdni(DniCliente);

	            TipoCuentaDao tipoCuentaDao = new TipoCuentaDaoImpl();
	            TipoCuenta tipoCuenta = tipoCuentaDao.obtenerCuentaXNombre(Tipo);

	            return new Cuenta(NroCuenta, cliente, CBU, tipoCuenta, FechaCreacion, Saldo, activa);
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    } finally {
	        try {
	            if (resultSet != null)
	                resultSet.close();
	            if (statement != null)
	                statement.close();
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	    }

	    return null;
	}
	
//	private double obtenerSaldoCuenta(String nroCuenta) {
//	    double saldo = 0.0;
//
//	    try (Connection conexion = Conexion.getConexion().getSQLConexion();
//	         PreparedStatement statement = conexion.prepareStatement("select Saldo from cuentas where NroCuenta = ?")) {
//
//	        statement.setString(1, nroCuenta);
//
//	        try (ResultSet resultSet = statement.executeQuery()) {
//	            if (resultSet.next()) {
//	                saldo = resultSet.getDouble("Saldo");
//	            }
//	        }
//
//	    } catch (SQLException e) {
//	        e.printStackTrace();
//	    }
//
//	    return saldo;
//	}
	


}