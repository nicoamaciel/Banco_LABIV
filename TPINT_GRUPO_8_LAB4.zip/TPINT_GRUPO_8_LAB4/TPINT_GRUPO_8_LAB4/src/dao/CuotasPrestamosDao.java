package dao;

import java.io.IOException;
import java.util.List;

import dominio.Cuenta;
import dominio.CuotasPrestamos;

public interface CuotasPrestamosDao {
	
	public boolean insert(CuotasPrestamos cuotasPrestamo);
	
}
