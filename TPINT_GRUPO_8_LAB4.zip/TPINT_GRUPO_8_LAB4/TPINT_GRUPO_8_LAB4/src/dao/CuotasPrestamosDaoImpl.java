package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import dominio.Cuenta;
import dominio.CuotasPrestamos;
import dominio.Movimiento;


public class CuotasPrestamosDaoImpl implements CuotasPrestamosDao {
	
	private static final String insert = "INSERT INTO cuotasprestamos(NroCuenta,Cuotas,ImporteSolicitado,PorcentajeInteres,ImporteFijoCuota,ImporteFinalConInteres,ImporteFinalCuota,Estado) VALUES(?,?,?,?,?,?,?,?)";
	
	private static final String prestamosXUsuario= "Select cp.ID_CuotasPrestamos, cp.cuotaspagas, cp.cuotas, cp.importesolicitado,cp.importefinalconinteres,cp.importefinalcuota,cp.estado from CuotasPrestamos as cp inner join Cuentas as cuenta on cuenta.nrocuenta = cp.nrocuenta inner join clientes as c on c.dni = cuenta.dniCliente where c.Email= ?";
	
	@Override
	public boolean insert(CuotasPrestamos cuotasPrestamo) {
		
		PreparedStatement statement;
		Connection conexion = Conexion.getConexion().getSQLConexion();
		boolean isInsertExitoso = false;
		try {
			statement = conexion.prepareStatement(insert);
			statement.setString(1, cuotasPrestamo.getNroCuenta());
			statement.setInt(2, cuotasPrestamo.getCuotas());
			statement.setDouble(3,cuotasPrestamo.getImporteSolicitado());
			statement.setDouble(4,cuotasPrestamo.getPorcentajeInteres());
			statement.setDouble(5,cuotasPrestamo.getImporteFijoCuota());
			statement.setDouble(6,cuotasPrestamo.getImporteFinalconInteres());
			statement.setDouble(7,cuotasPrestamo.getImporteFinalCuota());
			statement.setBoolean(8, cuotasPrestamo.getEstado());
			if (statement.executeUpdate() > 0) {
				conexion.commit();
				isInsertExitoso = true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
			try {
				conexion.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
		}

		return isInsertExitoso;
	}

	public List<CuotasPrestamos> buscarPrestamos(String usuario) {
	
			ArrayList<CuotasPrestamos> Listado = new ArrayList<CuotasPrestamos>();
			Connection conexion = Conexion.getConexion().getSQLConexion();

			MovimientoDaoImpl movimientoDaoImpl= new MovimientoDaoImpl();
			
			try {
				
						
				try (PreparedStatement statement = conexion.prepareStatement(prestamosXUsuario)) {
	                statement.setString(1, usuario);

	                try (ResultSet resultSet = statement.executeQuery()) {
	                    while (resultSet.next()) {
	                    	
	                    	int idCuota = resultSet.getInt("ID_CuotasPrestamos");
	                        int cuotas = resultSet.getInt("cuotas");
	                        double importeSolicitado = resultSet.getDouble("importesolicitado");
	                        
	                        int cuotaspagas; 
	                        
	                        cuotaspagas= resultSet.getInt("cuotasPagas");
	                        
	                        if (resultSet.wasNull()) {
	                        	 cuotaspagas = 0;
	                        }
	                        
	                        
	                        double importeFinalConInteres = resultSet.getDouble("importefinalconinteres");
	                        double importeFinalCuota = resultSet.getDouble("importefinalcuota");
	                        boolean estado = resultSet.getBoolean("estado");
	                		
	                		CuotasPrestamos cuota = new CuotasPrestamos(idCuota, cuotas,cuotaspagas, importeSolicitado, importeFinalConInteres, importeFinalCuota, estado);
	                	
	                        Listado.add(cuota);
	                    }
	                }
	            }
	        
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }

	    return Listado;

	}

	public boolean PagarCuota(int id) {
		
        int[] cuotasPagasActual = obtenerCuotasPagas(id);

        
        int cuotasPagasNuevas = cuotasPagasActual[1] + 1;
		
        
        int idCuota= cuotasPagasActual[0];
        
	    PreparedStatement statement;
	    Connection conexion = Conexion.getConexion().getSQLConexion();
	    boolean isPagoExitoso = false;

	    try {
	       
	    	

	        
	        

	        String update = "UPDATE CuotasPrestamos SET CuotasPagas = ? WHERE ID_CuotasPrestamos = ?";
	        statement = conexion.prepareStatement(update);
	        System.out.println("Estop");
	        statement.setInt(1, cuotasPagasNuevas);
	        System.out.println("Paso uno");
	        statement.setInt(2, idCuota);
	        System.out.println("Paso dos");
	        
	        
	        if (statement.executeUpdate() > 0) {
	        	
	        	System.out.println("entro");
	            conexion.commit();
	            isPagoExitoso = true;
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	        
	    }

	    return isPagoExitoso;
		
	}

	private int[] obtenerCuotasPagas(int id) {
	    
		
	    

	    int[] resultado = new int[2];
	    int cuotasPagas = 0;

	    String select = "select CuotasPagas from CuotasPrestamos where ID_CuotasPrestamos = ?";

	    Connection conexion = null;
	    try {
	        conexion = Conexion.getConexion().getSQLConexion();
	        PreparedStatement statement = conexion.prepareStatement(select);
	        statement.setInt(1, id);

	        try (ResultSet resultSet = statement.executeQuery()) {
	            if (resultSet.next()) {
	                resultado[0] = id;
	                resultado[1] = resultSet.getInt("CuotasPagas");
	            }
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    } 

	    return resultado;
	}

	public CuotasPrestamos buscarPrestamoXid(int idPrestamoSeleccionado) {
	    CuotasPrestamos cuota = null;
	    Connection conexion = Conexion.getConexion().getSQLConexion();

	    try {
	        String query = "SELECT ID_CuotasPrestamos, cuotas, importesolicitado, cuotasPagas, importefinalconinteres, importefinalcuota, estado " +
	                       "FROM CuotasPrestamos WHERE ID_CuotasPrestamos = ?";
	        try (PreparedStatement statement = conexion.prepareStatement(query)) {
	            
	            statement.setInt(1, idPrestamoSeleccionado);

	            try (ResultSet resultSet = statement.executeQuery()) {
	                if (resultSet.next()) {
	                	
	                    int cuotas = resultSet.getInt("cuotas");
	                    double importeSolicitado = resultSet.getDouble("importesolicitado");
	                    int cuotasPagas = resultSet.getInt("cuotasPagas");
	                    double importeFinalConInteres = resultSet.getDouble("importefinalconinteres");
	                    double importeFinalCuota = resultSet.getDouble("importefinalcuota");
	                    boolean estado = resultSet.getBoolean("estado");

	                    cuota = new CuotasPrestamos(idPrestamoSeleccionado, cuotas, cuotasPagas, importeSolicitado, importeFinalConInteres, importeFinalCuota, estado);
	                }
	            }
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }

	    return cuota;
	}

	public CuotasPrestamos traerXid(String idPrestamoSeleccionado) {
	    CuotasPrestamos cuota = null;
	    Connection conexion = Conexion.getConexion().getSQLConexion();

	    try {
	        String query = "SELECT ID_CuotasPrestamos,NroCuenta, cuotas, importesolicitado, cuotasPagas, importefinalconinteres, importefinalcuota, estado " +
	                        "FROM CuotasPrestamos WHERE ID_CuotasPrestamos = ?";
	        try (PreparedStatement statement = conexion.prepareStatement(query)) {
	            
	          
	            int id = Integer.parseInt(idPrestamoSeleccionado);
	            
	            
	            
	            statement.setInt(1, id);

	            try (ResultSet resultSet = statement.executeQuery()) {
	                if (resultSet.next()) {
	                    
	                	
	                	System.out.println("id: " +id);
	                	String nroCuentas=resultSet.getString("NroCuenta");
	                	
	                    int cuotas = resultSet.getInt("cuotas");
	                    double importeSolicitado = resultSet.getDouble("importesolicitado");
	                    int cuotasPagas = resultSet.getInt("cuotasPagas");
	                    double importeFinalConInteres = resultSet.getDouble("importefinalconinteres");
	                    double importeFinalCuota = resultSet.getDouble("importefinalcuota");
	                    boolean estado = resultSet.getBoolean("estado");
	                    
	                    
	                    cuota = new CuotasPrestamos(id, cuotas, cuotasPagas, importeSolicitado, importeFinalConInteres, importeFinalCuota, estado,nroCuentas);
	                }
	            }
	        }
	    } catch (SQLException | NumberFormatException e) {
	        e.printStackTrace();
	    }

	    return cuota;
	}
	
}
