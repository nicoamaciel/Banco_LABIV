package dao;

import java.util.List;

import dominio.Movimiento;

public interface MovimientoDao {

	public boolean insert(Movimiento movimiento );
	public boolean deleteLogico (int ID);
	public List<Movimiento> readAll();
	
	public List<Movimiento> listaXNroCuenta (String NroCuenta);
	
	public List<Movimiento> readPrestamos();
	
	public boolean insertarTransferencia (Movimiento movimiento);
	
	public List <Movimiento> obtenerPrestamosXdni(String dni);
}
