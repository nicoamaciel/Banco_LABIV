package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import dominio.Cliente;
import dominio.Cuenta;
import dominio.CuotasPrestamos;
import dominio.Movimiento;
import dominio.TipoCuenta;
import dominio.TipoMovimiento;

public class MovimientoDaoImpl implements MovimientoDao {

	private static final String insert = "INSERT INTO db_banco.movimientos (NroCuenta,Detalle,Fecha,Importe,Movimiento,Cuotas,Activa) VALUES (?,?,?,?,?,?,?)";
	private static final String insertTransferencia = "INSERT into Movimientos (NroCuenta,Detalle,Fecha,Importe,Movimiento,Activa) VALUES (?,?,?,?,?,?)";
	
	private static final String readall = "SELECT * FROM db_banco.Movimientos";

	private static final String delete = "UPDATE cuentas SET activa = ? WHERE Id = ?";
	
	private static final String deleteFisico = "DELETE FROM Movimientos WHERE Id = ?";

	private static final String listarPrestamo = "Select * from db_banco.Movimientos";

	private static final String xId = "Select * from db_banco.Movimientos where id= ?";

	public Movimiento buscarXId(int id) {
		Movimiento movimiento = null;
		Connection conexion = Conexion.getConexion().getSQLConexion();

		try {
			try (PreparedStatement statement = conexion.prepareStatement(xId)) {
				statement.setInt(1, id);

				try (ResultSet resultSet = statement.executeQuery()) {
					if (resultSet.next()) {
						movimiento = getMovimiento2(resultSet);
					}
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return movimiento;
	}

	@Override
	public List<Movimiento> readPrestamos() {

		PreparedStatement statement;
		ResultSet resultSet;
		ArrayList<Movimiento> movimiento = new ArrayList<Movimiento>();
		Conexion conexion = Conexion.getConexion();

		try {
			statement = conexion.getSQLConexion().prepareStatement(listarPrestamo);

			resultSet = statement.executeQuery();
			while (resultSet.next()) {

				movimiento.add(getMovimiento2(resultSet));

			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return movimiento;

	}

	@Override
	public boolean insert(Movimiento movimiento) {
		PreparedStatement statement;
		Connection conexion = Conexion.getConexion().getSQLConexion();
		boolean isInsertExitoso = false;
		try {
			statement = conexion.prepareStatement(insert);
			statement.setString(1, movimiento.getNroCuenta());
			statement.setString(2, movimiento.getDetalle());
			statement.setString(3, movimiento.getFecha());
			statement.setDouble(4, movimiento.getImporte());
			statement.setString(5, movimiento.getTipoMovimiento().getDescripcion());
			statement.setInt(6, movimiento.getCuotas());
			statement.setBoolean(7, movimiento.getActiva());
			if (statement.executeUpdate() > 0) {
				conexion.commit();
				isInsertExitoso = true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
			try {
				conexion.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
		}

		return isInsertExitoso;
	}

	@Override
	public boolean deleteLogico(int Id) {
		PreparedStatement statement;
		Connection conexion = Conexion.getConexion().getSQLConexion();
		boolean isDeleteExitoso = false;
		try {
			statement = conexion.prepareStatement(delete);
			statement.setBoolean(1, false);
			statement.setInt(2, Id);
			if (statement.executeUpdate() > 0) {
				conexion.commit();
				isDeleteExitoso = true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
			try {
				conexion.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
		}
		return isDeleteExitoso;
	}

	public boolean negarPrestamo(int Id) {
		PreparedStatement statement;
		Connection conexion = Conexion.getConexion().getSQLConexion();
		boolean negarExitoso = false;
		try {
			statement = conexion.prepareStatement(deleteFisico);			
			statement.setInt(1, Id);
			if (statement.executeUpdate() > 0) {
				conexion.commit();
				negarExitoso = true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
			try {
				conexion.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
		}
		return negarExitoso;
	}
	@Override
	public List<Movimiento> readAll() {
		PreparedStatement statement;
		ResultSet resultSet;
		ArrayList<Movimiento> movimiento = new ArrayList<Movimiento>();
		Conexion conexion = Conexion.getConexion();
		try {
			statement = conexion.getSQLConexion().prepareStatement(readall);
			System.out.println("Consulta SQL: " + readall);
			resultSet = statement.executeQuery();
			while (resultSet.next()) {
				movimiento.add(getMovimiento(resultSet));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return movimiento;
	}

	private Movimiento getMovimiento(ResultSet resultSet) throws SQLException {

		String NroCuenta = resultSet.getString("NroCuenta");
		String Detalle = resultSet.getString("Detalle");
		String Fecha = resultSet.getString("Fecha");
		Double Importe = resultSet.getDouble("Importe");
		String Movimiento = resultSet.getString("Movimiento");
		int Cuota = resultSet.getInt("Cuotas");
		Boolean activa = resultSet.getBoolean("activa");

		TipoMovimientoDao tipoMovimientoDao = new TipoMovimientoDaoImpl();
   		
   		TipoMovimiento tipoMovimiento = tipoMovimientoDao.obtenerMovimientoXDescripcion(null);
        
		return new Movimiento(NroCuenta, Detalle, Fecha, Importe, tipoMovimiento, Cuota, activa);
	}

	private Movimiento getMovimiento2(ResultSet resultSet) throws SQLException {

		int NroMovimiento = resultSet.getInt("id");
		String NroCuenta = resultSet.getString("NroCuenta");
		String Detalle = resultSet.getString("Detalle");
		String Fecha = resultSet.getString("Fecha");
		Double Importe = resultSet.getDouble("Importe");
		String Movimiento = resultSet.getString("Movimiento");
		int Cuota = resultSet.getInt("Cuotas");
		Boolean activa = resultSet.getBoolean("activa");

	TipoMovimientoDao tipoMovimientoDao = new TipoMovimientoDaoImpl();
   		
		TipoMovimiento tipoMovimiento = tipoMovimientoDao.obtenerMovimientoXDescripcion(null);
      
		return new Movimiento(NroMovimiento, NroCuenta, Detalle, Fecha, Importe, tipoMovimiento, Cuota, activa);
	}
	
	
	@Override
	public List<Movimiento> listaXNroCuenta(String NroCuenta) {
		ArrayList<Movimiento> Listado = new ArrayList<Movimiento>();
		Connection conexion = Conexion.getConexion().getSQLConexion();
		PreparedStatement statement = null;
		ResultSet resultSet = null;

		try {

			String consulta = "SELECT * FROM Movimientos Where NroCuenta = ?";
			statement = conexion.prepareStatement(consulta);
			statement.setString(1, NroCuenta);

			resultSet = statement.executeQuery();

			 while (resultSet.next()){

				String nroCuenta = resultSet.getString("NroCuenta");
				String detalle = resultSet.getString("Detalle");
				String fecha = resultSet.getString("Fecha");
				Double importe = resultSet.getDouble("Importe");
				String Movimiento = resultSet.getString("Movimiento");
				int cuota = resultSet.getInt("Cuotas");
				boolean activa = resultSet.getBoolean("activa");
				
				TipoMovimientoDao tipoMovimientoDao = new TipoMovimientoDaoImpl();
		   		
		   		TipoMovimiento tipoMovimiento = tipoMovimientoDao.obtenerMovimientoXDescripcion(Movimiento);
		      
				Movimiento movimiento = new Movimiento(nroCuenta, detalle, fecha, importe, tipoMovimiento, cuota,activa);

				Listado.add(movimiento);
			}

		} catch (

		SQLException e) {
			e.printStackTrace();
		}

		return Listado;
	}

	public boolean cambiarTrueMovimiento(int id) {
		Connection conexion = Conexion.getConexion().getSQLConexion();
		boolean isUpdateExitoso = false;

		try {
			String updateQuery = "UPDATE db_banco.movimientos SET Activa = true WHERE id = ?";

			try (PreparedStatement statement = conexion.prepareStatement(updateQuery)) {
				statement.setInt(1, id);

				if (statement.executeUpdate() > 0) {
					conexion.commit();
					isUpdateExitoso = true;
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
			try {
				conexion.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
		}

		return isUpdateExitoso;
	}

	public boolean crearMovPagoCuota(CuotasPrestamos cuoPres) {

		Movimiento movimiento = new Movimiento();
		TipoMovimiento tipo = new TipoMovimiento();
		tipo.setId(3);
		TipoMovimientoDaoImpl tipoDao = new TipoMovimientoDaoImpl();
		tipo = tipoDao.obtenerMovimientoXId(tipo.getId());
		//movimiento.setIdTipoMovimiento(3);
		
		movimiento.setTipoMovimiento(tipo);
		movimiento.setCuotas(1);
		movimiento.setImporte(cuoPres.getImporteFinalCuota());
		movimiento.setDetalle("Pago cuota prestamo");
		movimiento.setNroCuenta(cuoPres.getNroCuenta());
		movimiento.setActiva(true);

		LocalDate fechaActual = LocalDate.now();
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

		fechaActual.format(formatter);

		movimiento.setFecha(fechaActual.format(formatter));

		MovimientoDaoImpl movimientoDaoImpl = new MovimientoDaoImpl();

		return movimientoDaoImpl.insert(movimiento);

	}
	public boolean insertarTransferencia(Movimiento movimiento) {
		PreparedStatement statement;
		Connection conexion = Conexion.getConexion().getSQLConexion();
		boolean transferenciaExitosa = false;
		try {
			statement = conexion.prepareStatement(insertTransferencia);
 			statement.setString(1, movimiento.getNroCuenta());
			statement.setString(2, movimiento.getDetalle());
			statement.setString(3, movimiento.getFecha());
			statement.setDouble(4, movimiento.getImporte());
			statement.setString(5, String.valueOf(movimiento.getTipoMovimiento().getDescripcion()));

			statement.setBoolean(6, movimiento.getActiva());
				if (statement.executeUpdate() > 0) {
				conexion.commit();
				transferenciaExitosa = true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
			try {
				conexion.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
		}

		return transferenciaExitosa;
	}

	@Override
	public List<Movimiento> obtenerPrestamosXdni(String dni) {
		ArrayList<Movimiento> Listado = new ArrayList<Movimiento>();
		Connection conexion = Conexion.getConexion().getSQLConexion();

		try {
			String consulta = "SELECT * FROM db_banco.movimientos m join db_banco.cuentas c on m.NroCuenta = c.NroCuenta Where c.DniCliente = ?";
			
					
			try (PreparedStatement statement = conexion.prepareStatement(consulta)) {
                statement.setString(1, dni);

                try (ResultSet resultSet = statement.executeQuery()) {
                    while (resultSet.next()) {
                    	String NroCuenta = resultSet.getString("NroCuenta");
        				String detalle = resultSet.getString("Detalle");
        				String fecha = resultSet.getString("Fecha");
        				Double importe = resultSet.getDouble("Importe");
        				String Movimiento = resultSet.getString("Movimiento");
        				int cuota = resultSet.getInt("Cuotas");
        				boolean activa = resultSet.getBoolean("activa");
        				
        				TipoMovimientoDao tipoMovimientoDao = new TipoMovimientoDaoImpl();
        		   		
        		   		TipoMovimiento tipoMovimiento = tipoMovimientoDao.obtenerMovimientoXDescripcion(Movimiento);
        		      
        				Movimiento movimiento = new Movimiento(NroCuenta, detalle, fecha, importe, tipoMovimiento, cuota,activa);

        				Listado.add(movimiento);
                    }
                }
            }
        
    } catch (SQLException e) {
        e.printStackTrace();
    }

    return Listado;
		
	}
	
	
		
	
}
