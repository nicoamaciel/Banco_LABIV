package dao;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import dominio.Cliente;

public interface ReportesDao {

	boolean exportClientes(PrintWriter writer);
	boolean exportCuentas(PrintWriter writer);
	boolean exportPrestamos(PrintWriter writer);
	boolean exportTransProp(PrintWriter writer);
	boolean exportTransTer(PrintWriter writer);
}
