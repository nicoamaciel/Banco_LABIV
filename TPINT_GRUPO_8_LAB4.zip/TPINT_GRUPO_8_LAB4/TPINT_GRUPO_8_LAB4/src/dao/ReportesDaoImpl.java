package dao;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
public class ReportesDaoImpl implements ReportesDao {
	

	@Override
	public boolean exportClientes(PrintWriter writer) {
		Connection conexion = null;
	    PreparedStatement statement = null;
	    ResultSet resultSet = null;
	    
	    try {
	        conexion = Conexion.getConexion().getSQLConexion();

	        if (conexion != null && !conexion.isClosed()) {
	            statement = conexion.prepareStatement("SELECT Nombre, Apellido, Dni, Email, Contrasenia FROM db_banco.clientes");
	            resultSet = statement.executeQuery();
	            
	            writer.println("Nombre,Apellido,Dni,Email,Contrasenia");
	            while (resultSet.next()) {
	                String columna1 = resultSet.getString("Nombre");
	                String columna2 = resultSet.getString("Apellido");
	                String columna3 = resultSet.getString("Dni");
	                String columna4 = resultSet.getString("Email");
	                String columna5 = resultSet.getString("Contrasenia");

	                
	                writer.println(columna1 + "," + columna2 + "," + columna3 + "," + columna4 + "," + columna5 + "," );
	                
	            }
	        } else {
	           
	            throw new IllegalStateException("La conexi�n est� cerrada.");
	        }
	    
	    }catch (SQLException e) {
	        
	        e.printStackTrace();
	    } finally {
	        // Cierre de recursos
	        try {
	            if (resultSet != null) {
	                resultSet.close();
	            }
	            
	           
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	    }

	    		
		return false;	
	}

	@Override
	public boolean exportCuentas(PrintWriter writer) {
		Connection conexion = null;
	    PreparedStatement statement = null;
	    ResultSet resultSet = null;
	    
	    try {
	        conexion = Conexion.getConexion().getSQLConexion();

	        if (conexion != null && !conexion.isClosed()) {
	            statement = conexion.prepareStatement("SELECT NroCuenta,DniCliente,CBU,Tipo,Saldo FROM db_banco.cuentas");
	            resultSet = statement.executeQuery();
	            
	            writer.println("NroCuenta,DniCliente,CBU,Tipo,Saldo");
	            while (resultSet.next()) {
	            	String columna1 = resultSet.getString("NroCuenta"); 
		            String columna2 = resultSet.getString("DniCliente");
		            String columna3 = resultSet.getString("CBU");
		            String columna4 = resultSet.getString("Tipo");
		            String columna5 = resultSet.getString("Saldo");

	                
	                writer.println(columna1 + "," + columna2 + "," + columna3 + "," + columna4 + "," + columna5 + "," );
	                
	            }
	        } else {
	           
	            throw new IllegalStateException("La conexi�n est� cerrada.");
	        }
	    
	    }catch (SQLException e) {
	        
	        e.printStackTrace();
	    } finally {
	        // Cierre de recursos
	        try {
	            if (resultSet != null) {
	                resultSet.close();
	            }
	           
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	    }

	    		
		return false;
		
		
		
	}

	@Override
	public boolean exportPrestamos(PrintWriter writer) {
		Connection conexion = null;
	    PreparedStatement statement = null;
	    ResultSet resultSet = null;
	    
	    try {
	        conexion = Conexion.getConexion().getSQLConexion();

	        if (conexion != null && !conexion.isClosed()) {
	            statement = conexion.prepareStatement("SELECT NroCuenta, Detalle, Fecha, Importe, Cuotas FROM db_banco.movimientos where Movimiento  = 'Alta Prestamo'");
	            resultSet = statement.executeQuery();
	            
	            writer.println("NroCuenta,Detalle,Fecha,Importe,Cuotas");
	            while (resultSet.next()) {
	                String columna1 = resultSet.getString("NroCuenta");
	                String columna2 = resultSet.getString("Detalle");
	                String columna3 = resultSet.getString("Fecha");
	                int columna4 = resultSet.getInt("Importe");
	                int columna5 = resultSet.getInt("Cuotas");

	                
	                writer.println(columna1 + "," + columna2 + "," + columna3 + "," + columna4 + "," + columna5 + "," );
	                
	            }
	        } else {
	           
	            throw new IllegalStateException("La conexi�n est� cerrada.");
	        }
	    
	    }catch (SQLException e) {
	        
	        e.printStackTrace();
	    } finally {
	        // Cierre de recursos
	        try {
	            if (resultSet != null) {
	                resultSet.close();
	            }
	            
	           
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	    }

	    		
		return false;	
	}

	public boolean exportTransProp(PrintWriter writer) {
		Connection conexion = null;
	    PreparedStatement statement = null;
	    ResultSet resultSet = null;
	    
	    try {
	        conexion = Conexion.getConexion().getSQLConexion();

	        if (conexion != null && !conexion.isClosed()) {
	            statement = conexion.prepareStatement("SELECT Id, NroCuenta, Detalle, Fecha, Importe FROM db_banco.movimientos where Movimiento='Transferencia'");
	            resultSet = statement.executeQuery();
	            
	            writer.println("NroCuenta,Detalle,Fecha,Importe");
	            while (resultSet.next()) {
	                String columna1 = resultSet.getString("NroCuenta");
	                String columna2 = resultSet.getString("Detalle");
	                String columna3 = resultSet.getString("Fecha");
	                double columna4 = resultSet.getDouble("Importe");
	                

	                
	                writer.println(columna1 + "," + columna2 + "," + columna3 + "," + columna4 + "," );
	                
	            }
	        } else {
	           
	            throw new IllegalStateException("La conexi�n est� cerrada.");
	        }
	    
	    }catch (SQLException e) {
	        
	        e.printStackTrace();
	    } finally {
	        // Cierre de recursos
	        try {
	            if (resultSet != null) {
	                resultSet.close();
	            }
	            
	           
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	    }

	    		
		return false;	
		
	}
	
	
	
	public boolean exportTransTer(PrintWriter writer) {
		return false;
		
		
		
	}

	
}
