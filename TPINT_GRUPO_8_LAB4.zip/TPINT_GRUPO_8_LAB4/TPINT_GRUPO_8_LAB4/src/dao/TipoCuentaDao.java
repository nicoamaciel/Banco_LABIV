package dao;

import java.util.List;

import dominio.Cuenta;
import dominio.TipoCuenta;

public interface TipoCuentaDao {
	
	public TipoCuenta obtenerCuentaXNombre(String nombre);

	public List<TipoCuenta> readAll();
	
	public TipoCuenta obtenerCuentaXId(int Id);
	
}
