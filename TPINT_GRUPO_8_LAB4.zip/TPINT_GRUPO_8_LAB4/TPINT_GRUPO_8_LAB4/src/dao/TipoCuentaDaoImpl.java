package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import dominio.Cliente;
import dominio.Cuenta;
import dominio.TipoCuenta;

public class TipoCuentaDaoImpl implements TipoCuentaDao{
	private static final String readall = "SELECT * FROM db_banco.tiposcuenta";
	
	public TipoCuenta obtenerCuentaXNombre(String nombre) {
		PreparedStatement statement = null;
		ResultSet resultSet = null;
		Connection conexion = Conexion.getConexion().getSQLConexion();

		try {
			String consulta ="SELECT * FROM tiposcuenta WHERE descripcion = ?";
			statement = conexion.prepareStatement(consulta);
			statement.setString(1, nombre);

			resultSet = statement.executeQuery();

			if (resultSet.next()) {

				int Id = resultSet.getInt("Id");
				String Descripcion = resultSet.getString("Descripcion");
				
				TipoCuenta tipoCuenta = new TipoCuenta(Id,Descripcion);
				return tipoCuenta;

			}}
			catch (SQLException e) {
				e.printStackTrace();
			} finally {
				try {
					if (resultSet != null)
						resultSet.close();
					if (statement != null)
						statement.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}

			return null;
}

	@Override
	public List<TipoCuenta> readAll() {
		
		PreparedStatement statement;
		ResultSet resultSet; // Guarda el resultado de la query
		ArrayList<TipoCuenta> tipoCuenta = new ArrayList<TipoCuenta>();
		Conexion conexion = Conexion.getConexion();
		try {
			statement = conexion.getSQLConexion().prepareStatement(readall);
			System.out.println("Consulta SQL: " + readall);
			resultSet = statement.executeQuery();
			while (resultSet.next()) {
				tipoCuenta.add(getTiposCuenta(resultSet));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return tipoCuenta;
	}
	private TipoCuenta getTiposCuenta(ResultSet resultSet) throws SQLException {
		int Id = resultSet.getInt("Id");
		String Descripcion = resultSet.getString("Descripcion");
	
		
		 
		    
		return new TipoCuenta(Id,Descripcion);
	}

	@Override
	public TipoCuenta obtenerCuentaXId(int Id) {
		PreparedStatement statement = null;
		ResultSet resultSet = null;
		Connection conexion = Conexion.getConexion().getSQLConexion();

		try {
			String consulta ="SELECT * FROM tiposcuenta WHERE Id = ?";
			statement = conexion.prepareStatement(consulta);
			statement.setInt(1, Id);

			resultSet = statement.executeQuery();

			if (resultSet.next()) {

				int id = resultSet.getInt("Id");
				String Descripcion = resultSet.getString("Descripcion");
				
				TipoCuenta tipoCuenta = new TipoCuenta(id,Descripcion);
				return tipoCuenta;

			}}
			catch (SQLException e) {
				e.printStackTrace();
			} finally {
				try {
					if (resultSet != null)
						resultSet.close();
					if (statement != null)
						statement.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}

			return null;
	}
}
