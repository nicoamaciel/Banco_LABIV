package dao;


import java.util.List;



import dominio.TipoMovimiento;



public interface TipoMovimientoDao {
	

	public TipoMovimiento obtenerMovimientoXNombre(String nombre) ;
	public List<TipoMovimiento> readAll();
	public TipoMovimiento obtenerMovimientoXId(int Id);
	public TipoMovimiento obtenerMovimientoXDescripcion(String descripcion);
	
}