package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import dominio.Cliente;
import dominio.Cuenta;
import dominio.TipoCuenta;
import dominio.TipoMovimiento;

public class TipoMovimientoDaoImpl implements TipoMovimientoDao {
	private static final String readall = "SELECT * FROM db_banco.tiposmovimiento";

	public TipoMovimiento obtenerMovimientoXNombre(String nombre) {
		PreparedStatement statement = null;
		ResultSet resultSet = null;
		Connection conexion = Conexion.getConexion().getSQLConexion();

		try {
			String consulta = "SELECT * FROM tiposmovimiento WHERE descripcion = ?";
			statement = conexion.prepareStatement(consulta);
			statement.setString(1, nombre);

			resultSet = statement.executeQuery();

			if (resultSet.next()) {

				int Id = resultSet.getInt("Id");
				String Descripcion = resultSet.getString("Descripcion");

				TipoMovimiento tipoMovimiento = new TipoMovimiento(Id, Descripcion);
				return tipoMovimiento;

			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (resultSet != null)
					resultSet.close();
				if (statement != null)
					statement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		return null;
	}

	@Override
	public List<TipoMovimiento> readAll() {

		PreparedStatement statement;
		ResultSet resultSet; // Guarda el resultado de la query
		ArrayList<TipoMovimiento> tipoMovimiento = new ArrayList<TipoMovimiento>();
		Conexion conexion = Conexion.getConexion();
		try {
			statement = conexion.getSQLConexion().prepareStatement(readall);
			resultSet = statement.executeQuery();
			while (resultSet.next()) {
				tipoMovimiento.add(getTipoMovimiento(resultSet));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return tipoMovimiento;
	}

	private TipoMovimiento getTipoMovimiento(ResultSet resultSet) throws SQLException {
		int id = resultSet.getInt("Id");
		String descripcion = resultSet.getString("Descripcion");
		return new TipoMovimiento(id, descripcion);
	}

	@Override
	public TipoMovimiento obtenerMovimientoXId(int Id) {
		PreparedStatement statement = null;
		ResultSet resultSet = null;
		Connection conexion = Conexion.getConexion().getSQLConexion();

		try {
			String consulta = "SELECT * FROM tiposmovimiento WHERE Id = ?";
			statement = conexion.prepareStatement(consulta);
			statement.setInt(1, Id);

			resultSet = statement.executeQuery();

			if (resultSet.next()) {

				int id = resultSet.getInt("Id");
				String Descripcion = resultSet.getString("Descripcion");

				TipoMovimiento tipoMovimiento = new TipoMovimiento(id, Descripcion);
				return tipoMovimiento;

			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (resultSet != null)
					resultSet.close();
				if (statement != null)
					statement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		return null;
	}

	@Override
	public TipoMovimiento obtenerMovimientoXDescripcion(String descripcion) {
		PreparedStatement statement = null;
		ResultSet resultSet = null;
		Connection conexion = Conexion.getConexion().getSQLConexion();

		try {
			String consulta ="SELECT * FROM tiposmovimiento WHERE descripcion = ?";
			statement = conexion.prepareStatement(consulta);
			statement.setString(1, descripcion);

			resultSet = statement.executeQuery();

			if (resultSet.next()) {

				int Id = resultSet.getInt("Id");
				String Descripcion = resultSet.getString("Descripcion");
				
				TipoMovimiento tipoMovimiento = new TipoMovimiento(Id,Descripcion);
				return tipoMovimiento;

			}}
			catch (SQLException e) {
				e.printStackTrace();
			} finally {
				try {
					if (resultSet != null)
						resultSet.close();
					if (statement != null)
						statement.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}

			return null;
	}
}
