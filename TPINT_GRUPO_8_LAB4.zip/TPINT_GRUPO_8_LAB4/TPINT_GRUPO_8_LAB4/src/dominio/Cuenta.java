package dominio;
import java.util.Random;
public class Cuenta {
	
	private String NroCuenta;
	private Cliente cliente;
	private String CBU ;
	private TipoCuenta tipoCuenta;
	private String FechaCreacion;
	private double Saldo;
	private double DeudaPrestamo;
	private int CuotasPendientes; 
	private boolean Activa;
	
	
	
	public Cuenta()
	{
		
	}
	
	public boolean getActiva() {
		return Activa;
	}

	public void setActiva(boolean activa) {
		Activa = activa;
	}

	 private String generarCBU() {
	        int longitudCBU = 22; 
	        StringBuilder cbuBuilder = new StringBuilder();
	        Random random = new Random();

	        for (int i = 0; i < longitudCBU; i++) {
	            int digito = random.nextInt(10); 
	            cbuBuilder.append(digito);
	        }

	        return cbuBuilder.toString();
	    }

	 private String generarNroCuenta() {
	        int longitudCBU = 20; 
	        StringBuilder cbuBuilder = new StringBuilder();
	        Random random = new Random();

	        for (int i = 0; i < longitudCBU; i++) {
	            int digito = random.nextInt(10); 
	            cbuBuilder.append(digito);
	        }

	        return cbuBuilder.toString();
	    }

	
	public Cuenta(Cliente cliente,TipoCuenta tipoCuenta,String FechaCreacion,boolean Activa){
		this.NroCuenta = generarNroCuenta();
		this.cliente=cliente;
		this.CBU = generarCBU();
		this.tipoCuenta = tipoCuenta;
		this.FechaCreacion = FechaCreacion;
		this.Saldo = 10000.00;
		this.Activa = Activa;
	}
	
	

	public TipoCuenta getTipoCuenta() {
		return tipoCuenta;
	}

	public void setTipoCuenta(TipoCuenta Tipo) {
		tipoCuenta = Tipo;
	}

	public Cuenta(String nroCuenta, Cliente client, String cBU, TipoCuenta tipocuenta, String fechaCreacion,
			double saldo, boolean activa) {
		
		NroCuenta = nroCuenta;
		cliente= client;
		CBU = cBU;
		tipoCuenta = tipocuenta;
		FechaCreacion = fechaCreacion;
		Saldo = saldo;
		Activa = activa;
	}

	public String getNroCuenta() {
		return NroCuenta;
	}

	public void setNroCuenta(String nroCuenta) {
		NroCuenta = nroCuenta;
	}

	public String getCBU() {
		return CBU;
	}

	public void setCBU(String cBU) {
		CBU = cBU;
	}

	public TipoCuenta getTipo() {
		return tipoCuenta;
	}

	public void setTipo(TipoCuenta Tipo) {
		tipoCuenta = Tipo;
	}

	public String getFechaCreacion() {
		return FechaCreacion;
	}

	public void setFechaCreacion(String fechaCreacion) {
		FechaCreacion = fechaCreacion;
	}

	public double getSaldo() {
		return Saldo;
	}

	public void setSaldo(double saldo) {
		Saldo = saldo;
	}


	public Cliente getCliente() {
		return cliente;
	}
	
	public void setCliente(Cliente client) {
		cliente = client;
	}

	public double getDeudaPrestamo() {
		return DeudaPrestamo;
	}

	public void setDeudaPrestamo(double deudaPrestamo) {
		DeudaPrestamo = deudaPrestamo;
	}

	public int getCuotasPendientes() {
		return CuotasPendientes;
	}

	public void setCuotasPendientes(int cuotasPendientes) {
		CuotasPendientes = cuotasPendientes;
	}

	
	@Override
	public String toString() {
	    return "Cuenta [NroCuenta=" + NroCuenta + ", DniCliente=" + (cliente != null ? cliente.getDni() : "N/A") + ", CBU=" + CBU
	            + ", TipoCuenta=" + (tipoCuenta != null ? tipoCuenta.getDescripcion() : "N/A") + ", FechaCreacion=" + FechaCreacion
	            + ", Saldo=" + Saldo + ", DeudaPrestamo=" + DeudaPrestamo + ", CuotasPendientes=" + CuotasPendientes + ", Activa=" + Activa + "]";
	}

	
	
	
}

