package dominio;
import java.util.Random;
public class CuotasPrestamos {
	
	
	

	String NroCuenta;
	int Cuotas ;
	double ImporteSolicitado;
	double PorcentajeInteres;
	double ImporteFijoCuota;
	double ImporteFinalconInteres;
	double ImporteFinalCuota;
	int CuotasPagas;
	public int getCuotasPagas() {
		return CuotasPagas;
	}

	public CuotasPrestamos() {
		// TODO Auto-generated constructor stub
	}
	
	public void setCuotasPagas(int cuotasPagas) {
		CuotasPagas = cuotasPagas;
	}

	boolean Estado;
	
	
	int idCuota;
	
	
	public int getIdCuota() {
		return idCuota;
	}

	public void setIdCuota(int idCuota) {
		this.idCuota = idCuota;
	}
	
	public CuotasPrestamos(String nroCuenta, int cuotas, double impSolicitado, double porcentajeInteres, double importeFijoCuota, double importeFinalInteres, double importeFinalCuota,
			boolean estado) {
		super();
		CuotasPagas=0;
		NroCuenta = nroCuenta;
		Cuotas = cuotas;
		ImporteSolicitado = impSolicitado;
		PorcentajeInteres = porcentajeInteres;
		ImporteFijoCuota = importeFijoCuota;
		ImporteFinalconInteres = importeFinalInteres;
		ImporteFinalCuota = importeFinalCuota;
		Estado = estado;
	}

	
	public CuotasPrestamos(int id, String nroCuenta, int cuotas, double impSolicitado, double porcentajeInteres, double importeFijoCuota, double importeFinalInteres, double importeFinalCuota,
			boolean estado) {
		super();
		CuotasPagas=0;
		idCuota=id;
		NroCuenta = nroCuenta;
		Cuotas = cuotas;
		ImporteSolicitado = impSolicitado;
		PorcentajeInteres = porcentajeInteres;
		ImporteFijoCuota = importeFijoCuota;
		ImporteFinalconInteres = importeFinalInteres;
		ImporteFinalCuota = importeFinalCuota;
		Estado = estado;
	}
	
	public CuotasPrestamos(int idCuota2, int cuotas2, int cuotasPagas2, double importeSolicitado2, double importeFinalConInteres2,
			double importeFinalCuota2, boolean estado2) {
		
				idCuota=idCuota2;
				Cuotas = cuotas2;
				CuotasPagas=cuotasPagas2;
				ImporteSolicitado = importeSolicitado2;
				ImporteFinalconInteres = importeFinalConInteres2;
				ImporteFinalCuota = importeFinalCuota2;
				Estado = estado2;
	}

	public CuotasPrestamos(int id, int cuotas2, int cuotasPagas2, double importeSolicitado2,
			double importeFinalConInteres2, double importeFinalCuota2, boolean estado2, String nroCuentas) {
		
		idCuota=id;
		Cuotas = cuotas2;
		CuotasPagas=cuotasPagas2;
		ImporteSolicitado = importeSolicitado2;
		ImporteFinalconInteres = importeFinalConInteres2;
		ImporteFinalCuota = importeFinalCuota2;
		Estado = estado2;
		NroCuenta= nroCuentas;
		// TODO Auto-generated constructor stub
	}

	public String getNroCuenta() {
		return NroCuenta;
	}

	public void setNroCuenta(String nroCuenta) {
		NroCuenta = nroCuenta;
	}

	public int getCuotas() {
		return Cuotas;
	}

	public void setCuotas(int cuotas) {
		Cuotas = cuotas;
	}

	public double getImporteSolicitado() {
		return ImporteSolicitado;
	}

	public void setImporteSolicitado(double importeSolicitado) {
		ImporteSolicitado = importeSolicitado;
	}

	public double getPorcentajeInteres() {
		return PorcentajeInteres;
	}

	public void setPorcentajeInteres(double porcentajeInteres) {
		PorcentajeInteres = porcentajeInteres;
	}

	public double getImporteFijoCuota() {
		return ImporteFijoCuota;
	}

	public void setImporteFijoCuota(double importeFijoCuota) {
		ImporteFijoCuota = importeFijoCuota;
	}

	public double getImporteFinalconInteres() {
		return ImporteFinalconInteres;
	}

	public void setImporteFinalconInteres(double importeFinalconInteres) {
		ImporteFinalconInteres = importeFinalconInteres;
	}

	public double getImporteFinalCuota() {
		return ImporteFinalCuota;
	}

	public void setImporteFinalCuota(double importeFinalCuota) {
		ImporteFinalCuota = importeFinalCuota;
	}

	public boolean getEstado() {
		return Estado;
	}

	public void setEstado(boolean estado) {
		Estado = estado;
	}

	@Override
	public String toString() {
		return "CuotasPrestamos [NroCuenta=" + NroCuenta + ", Cuotas=" + Cuotas + ", ImporteSolicitado="
				+ ImporteSolicitado + ", PorcentajeInteres=" + PorcentajeInteres + ", ImporteFijoCuota="
				+ ImporteFijoCuota + ", ImporteFinalconInteres=" + ImporteFinalconInteres + ", ImporteFinalCuota="
				+ ImporteFinalCuota + ", Estado=" + Estado + "]";
	}
	
	
}
