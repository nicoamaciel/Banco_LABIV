package dominio;


public class Movimiento {
  
	private int NroMovimiento;
	private String NroCuenta;
	private String Detalle;
	private String Fecha;
	private double Importe;	
	private TipoMovimiento tipoMovimiento;
	private int Cuotas;
	private boolean Activa;
	
	public int getNroMovimiento() {
		return NroMovimiento;
	}


	public void setNroMovimiento(int nroMovimiento) {
		NroMovimiento = nroMovimiento;
	}

	public Movimiento( String nroCuenta, String detalle, String fecha, double importe, TipoMovimiento IdtipoMovimiento, int cuotas,
			boolean activa) {
		super();
		NroCuenta = nroCuenta;
		Detalle = detalle;
		Fecha = fecha;
		Importe = importe;
		tipoMovimiento = IdtipoMovimiento;
		Cuotas = cuotas;
		Activa = activa;
	}
	
	
	public Movimiento() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
	public Movimiento(int nroMovimiento2, String nroCuenta2, String detalle2, String fecha2, Double importe2,
			TipoMovimiento idTipoMovimiento2, int cuota2, Boolean activa2) {
		
		NroMovimiento= nroMovimiento2;
		NroCuenta = nroCuenta2;
		Detalle = detalle2;
		Fecha = fecha2;
		Importe = importe2;
		tipoMovimiento = idTipoMovimiento2;
		Cuotas = cuota2;
		Activa = activa2;
		
	}
	
	public Movimiento(String nroCuenta, String detalle, String fecha, Double importe,
			TipoMovimiento idTipoMovimiento, Boolean activa) {
		
		
		NroCuenta = nroCuenta;
		Detalle = detalle;
		Fecha = fecha;
		Importe = importe;
		tipoMovimiento = idTipoMovimiento;
		Activa = activa;
		
	}
	
	public TipoMovimiento getTipoMovimiento() {
		return tipoMovimiento;
	}


	public void setTipoMovimiento(TipoMovimiento tipoMovimiento) {
		this.tipoMovimiento = tipoMovimiento;
	}

	
	public String getNroCuenta() {
		return NroCuenta;
	}
	public void setNroCuenta(String nroCuenta) {
		NroCuenta = nroCuenta;
	}
	public String getDetalle() {
		return Detalle;
	}
	public void setDetalle(String detalle) {
		Detalle = detalle;
	}
	public String getFecha() {
		return Fecha;
	}
	public void setFecha(String fecha) {
		Fecha = fecha;
	}
	public double getImporte() {
		return Importe;
	}
	public void setImporte(double importe) {
		Importe = importe;
	}
	
	
	
	public int getCuotas() {
		return Cuotas;
	}


	public void setCuotas(int cuotas) {
		Cuotas = cuotas;
	}


	public boolean getActiva() {
		return Activa;
	}
	public void setActiva(boolean activa) {
		Activa = activa;
	}
	
	@Override
	public String toString() {
		return "Movimientos [ NroCuenta=" + NroCuenta + ", Detalle=" + Detalle + ", Fecha=" + Fecha
				+ ", Importe=" + Importe + ", TipoMovimiento=" + tipoMovimiento + ", Activa=" + Activa + "]";
	}
}