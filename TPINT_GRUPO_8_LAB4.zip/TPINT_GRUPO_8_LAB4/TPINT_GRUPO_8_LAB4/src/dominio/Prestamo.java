package dominio;

public class Prestamo {

	private int nroPrestamo;
	private int nroMovimiento;

	private String NroCuenta;
	private String Dni;
	private String Detalle;
	private String Fecha;

	private int Cuotas;
	private boolean Activa;
	
	
	public int getNroMovimiento() {
		return nroMovimiento;
	}
	public void setNroMovimiento(int nroMovimiento) {
		this.nroMovimiento = nroMovimiento;
	}
	public Prestamo(int nroPrestamo, String nroCuenta, String dni, String detalle, String fecha, int cuota,
			double importe, int cuotas, boolean activa) {
		super();
		this.nroPrestamo = nroPrestamo;
		NroCuenta = nroCuenta;
		Dni = dni;
		Detalle = detalle;
		Fecha = fecha;
		Cuotas = cuotas;
		Importe = importe;

		Activa = activa;
	}
	public int getCuota() {
		return Cuotas;
	}
	public void setCuota(int cuota) {
		Cuotas = cuota;
	}
	private double Importe;	
	
	
	public int getNroPrestamo() {
		return nroPrestamo;
	}
	public void setNroPrestamo(int nroPrestamo) {
		this.nroPrestamo = nroPrestamo;
	}
	
	public String getNroCuenta() {
		return NroCuenta;
	}
	public Prestamo() {
		super();
		// TODO Auto-generated constructor stub
	}
	public void setNroCuenta(String nroCuenta) {
		NroCuenta = nroCuenta;
	}
	public String getDni() {
		return Dni;
	}
	public void setDni(String dni) {
		Dni = dni;
	}
	public String getDetalle() {
		return Detalle;
	}
	public void setDetalle(String detalle) {
		Detalle = detalle;
	}
	public String getFecha() {
		return Fecha;
	}
	public void setFecha(String fecha) {
		Fecha = fecha;
	}
	public double getImporte() {
		return Importe;
	}
	public void setImporte(double importe) {
		Importe = importe;
	}
	public int getCuotas() {
		return Cuotas;
	}
	public void setCuotas(int cuotas) {
		Cuotas = cuotas;
	}
	public boolean isActiva() {
		return Activa;
	}
	public void setActiva(boolean activa) {
		Activa = activa;
	}
	@Override
	public String toString() {
		return "Prestamo [nroPrestamo=" + nroPrestamo + ", NroCuenta=" + NroCuenta + ", Dni=" + Dni + ", Detalle="
				+ Detalle + ", Fecha=" + Fecha + ", Cuota=" + Cuotas + ", Importe=" + Importe + ", Cuotas=" + Cuotas
				+ ", Activa=" + Activa + "]";
	}

	
}
