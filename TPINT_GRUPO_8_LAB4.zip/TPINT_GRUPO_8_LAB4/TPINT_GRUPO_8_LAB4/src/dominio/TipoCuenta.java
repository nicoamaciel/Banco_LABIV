package dominio;

public class TipoCuenta {
 private int Id;
 private String Descripcion;
 
public TipoCuenta(){
	 
 }

public TipoCuenta(int id, String descripcion) {
	this.Id = id;
	this.Descripcion = descripcion;
}

public int getId() {
	return Id;
}

public void setId(int id) {
	Id = id;
}

public String getDescripcion() {
	return Descripcion;
}

public void setDescripcion(String descripcion) {
	Descripcion = descripcion;
};
 
 
}

  