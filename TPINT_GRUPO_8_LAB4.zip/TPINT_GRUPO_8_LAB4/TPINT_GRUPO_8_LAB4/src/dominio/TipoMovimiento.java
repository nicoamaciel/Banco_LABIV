package dominio;

public class TipoMovimiento {
 private int Id;
 private String Descripcion;
 
public TipoMovimiento(){
	 
 }

public TipoMovimiento(int id, String descripcion) {
	this.Id = id;
	this.Descripcion = descripcion;
}

public int getId() {
	return Id;
}

public void setId(int id) {
	Id = id;
}

public String getDescripcion() {
	return Descripcion;
}

public void setDescripcion(String descripcion) {
	Descripcion = descripcion;
}

public static void add(Object tipoMovimiento) {
	// TODO Auto-generated method stub
	
};
 
 
}

  