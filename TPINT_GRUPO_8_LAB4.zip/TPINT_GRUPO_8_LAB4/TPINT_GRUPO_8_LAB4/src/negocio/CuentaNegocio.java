package negocio;

import java.util.ArrayList;
import java.util.List;

import dao.ClienteDaoImpl;
import dao.CuentaDao;
import dao.CuentaDaoImpl;
import dominio.Cliente;
import dominio.Cuenta;
import dominio.CuotasPrestamos;

public class CuentaNegocio {

	private CuentaDao cuentaD;

	public CuentaNegocio() {

		this.cuentaD = new CuentaDaoImpl();
	}

	public List<Cuenta> listaCuentaXdni(String dni) {
		CuentaDaoImpl cuentasDaoImpl = new CuentaDaoImpl();
		List<Cuenta> cuentas = new ArrayList<Cuenta>();

		cuentas = cuentasDaoImpl.listaCuentaXdni(dni);

		return cuentas;
	}

	public boolean darBajaCuenta(String cbu) {
		CuentaDaoImpl cuentaDaoImpl = new CuentaDaoImpl();

		return cuentaDaoImpl.deleteLogico(cbu);
	}

	public boolean crearCuenta(Cuenta cuenta) {
		CuentaDaoImpl cuentaDaoImpl = new CuentaDaoImpl();

		return cuentaDaoImpl.insert(cuenta);
	}

	public Cuenta obtenerCuentaXNroCbu(String cbu) {
		CuentaDaoImpl cuentaDaoImpl = new CuentaDaoImpl();
		Cuenta cuenta = cuentaDaoImpl.obtenerCuentaXCbu(cbu);

		return cuenta;
	}

	public Cuenta obtenerCuentaXNroCuenta(String nroCuenta) {
		CuentaDaoImpl cuentaDaoImpl = new CuentaDaoImpl();
		Cuenta cuenta = cuentaDaoImpl.obtenerCuentaXnroCuenta(nroCuenta);

		return cuenta;
	}
	
	

	public List<Cuenta> obtenerCuentaXemail(String email) {
		CuentaDaoImpl cuentasDaoImpl = new CuentaDaoImpl();
		List<Cuenta> cuentas = new ArrayList<Cuenta>();

		cuentas = cuentasDaoImpl.obtenerCuentaXemail(email);

		return cuentas;
	}

	public List<Cuenta> listarCuentas() {
		CuentaDaoImpl cuentasDaoImpl = new CuentaDaoImpl();
		List<Cuenta> cuentas = new ArrayList<Cuenta>();
		cuentas = cuentasDaoImpl.readAll();
		return cuentas;
	}

	public boolean acreditarImporte(String nroCuenta, double importe) {

		CuentaDaoImpl cuentasDaoImpl = new CuentaDaoImpl();

		return cuentasDaoImpl.insertImporte(nroCuenta, importe);

	}

	public static boolean descontarDeCuenta(CuotasPrestamos cuotasPrestamos) {

		CuentaDaoImpl cuentaDaoImpl = new CuentaDaoImpl();

		return cuentaDaoImpl.restarCuotaPrestamo(cuotasPrestamos);

	}

	public boolean debitarImporte(String nroCuenta, double monto) {
		CuentaDaoImpl cuentasDaoImpl = new CuentaDaoImpl();

		 
		 return cuentasDaoImpl.debitarImporte(nroCuenta, monto);
	}

	public int cantidadCuentasNegocio(Cliente cliente) {
		CuentaDaoImpl cuentaDaoImpl= new CuentaDaoImpl();
		
		return cuentaDaoImpl.traerCantidad(cliente);
		
	}

	public Cuenta obtenerCuentaXDni(String dni) {
		CuentaDaoImpl cuentaDao = new CuentaDaoImpl();
		
		return cuentaDao.traerCuentaXdni(dni);
		
	}
}