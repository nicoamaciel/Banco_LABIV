package negocio;

import java.util.ArrayList;
import java.util.List;

import com.sun.org.apache.bcel.internal.generic.RETURN;

import dao.CuotasPrestamosDaoImpl;


import dominio.CuotasPrestamos;

public class CuotasPrestamosNegocio {
	
	
	public boolean crearCuotasPrestamo(CuotasPrestamos cuotas)
	{
		CuotasPrestamosDaoImpl cuoImp= new CuotasPrestamosDaoImpl();
		
		return cuoImp.insert(cuotas);
	}

	public List<CuotasPrestamos> obtenerPrestamos(String usuario) {
		
		CuotasPrestamosDaoImpl cuotaDao = new CuotasPrestamosDaoImpl();
		
		
		 	 return   cuotaDao.buscarPrestamos(usuario);
		
		
	}

	public boolean sumarCuotaPagada(int id) {
		
		
		CuotasPrestamosDaoImpl cuotasPrestamosDaoImpl= new CuotasPrestamosDaoImpl();
		
		return cuotasPrestamosDaoImpl.PagarCuota(id);
		
		
		
	}

	public CuotasPrestamos traerPrestamo(int idPrestamoSeleccionado) {
		
		CuotasPrestamosDaoImpl cuotasPrestamosDaoImpl= new CuotasPrestamosDaoImpl();
		
		
		return cuotasPrestamosDaoImpl.buscarPrestamoXid(idPrestamoSeleccionado);
		
		
	}

	public CuotasPrestamos traerPrestamoxId(String idPrestamoSeleccionado) {
		
		
		CuotasPrestamosDaoImpl cuotasPrestamosDaoImpl=new CuotasPrestamosDaoImpl();
		
		return cuotasPrestamosDaoImpl.traerXid(idPrestamoSeleccionado);
		
		
	}


	
}
