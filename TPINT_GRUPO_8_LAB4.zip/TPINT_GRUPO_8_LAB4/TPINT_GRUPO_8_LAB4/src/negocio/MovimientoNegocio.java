package negocio;

import java.util.ArrayList;
import java.util.List;

import com.sun.org.apache.bcel.internal.generic.RETURN;

import dao.CuentaDaoImpl;
import dao.MovimientoDaoImpl;
import dominio.Cuenta;
import dominio.CuotasPrestamos;
import dominio.Movimiento;

public class MovimientoNegocio {
	
	
	public void aprobarPrestamo(Movimiento move)
	{
		
		int id= move.getNroMovimiento();
		MovimientoDaoImpl movimientoDaoImpl = new MovimientoDaoImpl();
		
		 boolean resultado= movimientoDaoImpl.cambiarTrueMovimiento(id);
		
		 if(resultado == true)
		 {
			 CuentaNegocio cuentaNegocio =new CuentaNegocio();
			 String nrocuenta= move.getNroCuenta();
			 double importe = move.getImporte();
			 cuentaNegocio.acreditarImporte(nrocuenta,importe);
		 }
		
	}

	public boolean crearMovimiento(Movimiento movimiento)
	{
		MovimientoDaoImpl movimientoDaoImpl= new MovimientoDaoImpl();
		
		return movimientoDaoImpl.insert(movimiento);
	}
	public boolean crearTransferencia(Movimiento movimiento)
	{
		MovimientoDaoImpl movimientoDaoImpl= new MovimientoDaoImpl();
		
		return movimientoDaoImpl.insertarTransferencia(movimiento);
	}
	
	public List<Movimiento> listarMovimientos() {
		MovimientoDaoImpl movimientoDaoImpl = new MovimientoDaoImpl();
		List<Movimiento> movimientos= new ArrayList<Movimiento> ();
		movimientos=movimientoDaoImpl.readAll();
		return movimientos;
	}
	
	public boolean darBajaMovimiento(int Id)
	{
		MovimientoDaoImpl movimientoDaoImpl= new MovimientoDaoImpl();
		
		return movimientoDaoImpl.deleteLogico(Id);
	}
	public boolean negarPrestamo(int Id)
	{
		MovimientoDaoImpl movimientoDaoImpl= new MovimientoDaoImpl();
		
		return movimientoDaoImpl.negarPrestamo(Id);
	}
	
	
	public List<Movimiento> listarMovimientosXNroCuenta(String NroCuenta){
		MovimientoDaoImpl movimientoDaoImpl= new MovimientoDaoImpl();
		List<Movimiento> movimientos=new ArrayList<Movimiento>();
		movimientos= movimientoDaoImpl.listaXNroCuenta(NroCuenta);
		return movimientos;
	}
	
	
	
	public Movimiento obtenerPrestamoPorId(int id)
	{
		MovimientoDaoImpl movimientoDaoImpl = new MovimientoDaoImpl();
		
		Movimiento movimiento= new Movimiento();
		
		movimiento= movimientoDaoImpl.buscarXId(id);
		
		return movimiento;
	}

	public boolean crearMovimientoPago(CuotasPrestamos cuoPres) {
		
		MovimientoDaoImpl movimientoDaoImpl= new MovimientoDaoImpl();
		
		return movimientoDaoImpl.crearMovPagoCuota(cuoPres);
		
		
	}
	
}
