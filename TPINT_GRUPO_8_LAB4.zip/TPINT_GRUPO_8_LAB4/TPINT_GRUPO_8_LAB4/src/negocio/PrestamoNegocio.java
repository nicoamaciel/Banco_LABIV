package negocio;

import java.util.ArrayList;
import java.util.List;

import dao.ClienteDaoImpl;
import dao.MovimientoDaoImpl;
import dominio.Cliente;
import dominio.Movimiento;
import dominio.Prestamo;

public class PrestamoNegocio {

	public List<Prestamo> obtenerPrestamos()
	{
		MovimientoDaoImpl daoMovimiento = new MovimientoDaoImpl();
		//////////////////solo leer los tipo 2
		ArrayList<Movimiento> listaPrestamo=(ArrayList<Movimiento>) daoMovimiento.readPrestamos();
		

		
		List<Prestamo> listaPrestamos = new ArrayList<>();
		
		ClienteDaoImpl clienteDao = new ClienteDaoImpl();
		
		for (Movimiento move : listaPrestamo) {
			Prestamo prestamo = new Prestamo();
			
			prestamo.setNroMovimiento(move.getNroMovimiento());
			prestamo.setNroCuenta(move.getNroCuenta());
            prestamo.setCuotas(move.getCuotas());
            prestamo.setDetalle(move.getDetalle());
            prestamo.setFecha(move.getFecha());
            prestamo.setImporte(move.getImporte());
            prestamo.setActiva(move.getActiva());
            
            Cliente cliente = clienteDao.obtenerClienteXNroCuenta(move.getNroCuenta());
            
            if (cliente != null) {
                prestamo.setDni(cliente.getDni());
            }

           
            listaPrestamos.add(prestamo);

		}
		

		return listaPrestamos;
	}
	
	public List <Prestamo> obtenerPrestamosXdni(String dni){
		MovimientoDaoImpl daoMovimiento = new MovimientoDaoImpl();
		
		ArrayList<Movimiento> listaPrestamo=(ArrayList<Movimiento>) daoMovimiento.obtenerPrestamosXdni(dni);
		
List<Prestamo> listaPrestamos = new ArrayList<>();
		
		ClienteDaoImpl clienteDao = new ClienteDaoImpl();
		
		for (Movimiento move : listaPrestamo) {
			Prestamo prestamo = new Prestamo();
			
			prestamo.setNroMovimiento(move.getNroMovimiento());
			prestamo.setNroCuenta(move.getNroCuenta());
            prestamo.setCuotas(move.getCuotas());
            prestamo.setDetalle(move.getDetalle());
            prestamo.setFecha(move.getFecha());
            prestamo.setImporte(move.getImporte());
            prestamo.setActiva(move.getActiva());
            
            Cliente cliente = clienteDao.obtenerClienteXNroCuenta(move.getNroCuenta());
            
            if (cliente != null) {
                prestamo.setDni(cliente.getDni());
            }

           
            listaPrestamos.add(prestamo);
	
		}
		return listaPrestamos;
}}
