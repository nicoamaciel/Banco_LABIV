package negocio;

import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import dao.ClienteDaoImpl;
import dao.CuentaDao;
import dao.CuentaDaoImpl;
import dao.MovimientoDaoImpl;
import dao.ReportesDaoImpl;
import dominio.Cliente;
import dominio.Cuenta;

public class ReportesNegocio {
	

	public boolean crearReporteClientes(PrintWriter writer)
	{
		ReportesDaoImpl repoDaoImpl= new ReportesDaoImpl();
		return repoDaoImpl.exportClientes(writer);
	}
	
	public boolean crearReporteCuentas(PrintWriter writer)
	{
		ReportesDaoImpl repoDaoImpl= new ReportesDaoImpl();
		return repoDaoImpl.exportCuentas(writer);
	}
	
	
	public boolean crearReportePrestasmos(PrintWriter writer)
	{
		ReportesDaoImpl repoDaoImpl= new ReportesDaoImpl();
		return repoDaoImpl.exportPrestamos(writer);
	}


	public boolean crearReporteTransProp(PrintWriter writer) {
		ReportesDaoImpl repoDaoImpl= new ReportesDaoImpl();
		return repoDaoImpl.exportTransProp(writer);
		
	}
		
	
}