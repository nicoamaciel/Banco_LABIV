package negocio;

import java.util.ArrayList;
import java.util.List;



import dao.ClienteDaoImpl;
import dao.CuentaDaoImpl;
import dao.TipoCuentaDaoImpl;
import dominio.Cliente;
import dominio.Cuenta;
import dominio.TipoCuenta;

public class TipoCuentaNegocio {

	public TipoCuenta obtenerTipoCuentaXNombre(String nombre) {
		TipoCuentaDaoImpl tipoCuentaDaoImpl= new TipoCuentaDaoImpl();
		TipoCuenta tipocuenta= new TipoCuenta();
		
		tipocuenta=tipoCuentaDaoImpl.obtenerCuentaXNombre(nombre);
		
		return tipocuenta;

	}

	public List<TipoCuenta> ListartiposCuenta() {
	    TipoCuentaDaoImpl tipocuentasDaoImpl = new TipoCuentaDaoImpl();
	    List<TipoCuenta> tiposcuentas = new ArrayList<TipoCuenta>();
	    tiposcuentas = tipocuentasDaoImpl.readAll();
	    return tiposcuentas;
	}

	public TipoCuenta obtenerTipoCuentaXId(int Id) {
		TipoCuentaDaoImpl tipoCuentaDaoImpl= new TipoCuentaDaoImpl();
		TipoCuenta tipocuenta= new TipoCuenta();
		
		tipocuenta=tipoCuentaDaoImpl.obtenerCuentaXId(Id);
		
		return tipocuenta;

	}
}
