package negocio;


import dao.TipoMovimientoDaoImpl;
import dominio.TipoMovimiento;

public class TipoMovimientoNegocio {

	public TipoMovimiento obtenerTipoMovimientoXId(int Id) {
		TipoMovimientoDaoImpl tipoMovimientoDaoImpl= new TipoMovimientoDaoImpl();
		TipoMovimiento tipomovimiento= new TipoMovimiento();
		
		tipomovimiento=tipoMovimientoDaoImpl.obtenerMovimientoXId(Id);
		
		return tipomovimiento;

	}
}
