package servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.ClienteDaoImpl;
import dao.CuentaDaoImpl;
import dominio.Cliente;
import dominio.Cuenta;
import dominio.Movimiento;
import negocio.CuentaNegocio;
import negocio.MovimientoNegocio;

/**
 * Servlet implementation class servletBajaConfirmar
 */
@WebServlet("/servletBajaConfirmar")
public class servletBajaConfirmar extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public servletBajaConfirmar() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		
		if (request.getParameter("btnConfirmarBaja") != null) {
			CuentaNegocio cuentaNegocio = new CuentaNegocio();

			String cbuCuenta = request.getParameter("CbuBaja");
			boolean resultado = cuentaNegocio.darBajaCuenta(cbuCuenta);
			System.out.println("resultado baja: " + resultado);
			System.out.println("cbuCuenta a bajar: " + cbuCuenta);

			if (resultado == true) {
				response.sendRedirect("BajaCuentaExitosa.jsp");

			}
		}
		if (request.getParameter("btnCancelar") != null) {
			request.getRequestDispatcher("BajaCuenta.jsp").forward(request, response);
		}

	}
}
