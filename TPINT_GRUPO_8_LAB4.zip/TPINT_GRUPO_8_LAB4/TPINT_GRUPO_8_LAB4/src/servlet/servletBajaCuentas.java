package servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.ClienteDaoImpl;
import dao.CuentaDaoImpl;
import dominio.Cliente;
import dominio.Cuenta;
import dominio.Movimiento;
import negocio.CuentaNegocio;
import negocio.MovimientoNegocio;

/**
 * Servlet implementation class servletBajaCuentas
 */
@WebServlet("/servletBajaCuentas")
public class servletBajaCuentas extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public servletBajaCuentas() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		if (request.getParameter("btnListarCuentas") != null) {
			CuentaNegocio cuentaNegocio1 = new CuentaNegocio();

			ArrayList<Cuenta> listaCuentas = (ArrayList<Cuenta>) cuentaNegocio1.listarCuentas();
			System.out.println(listaCuentas.toString());

			int pageSize = 10;
			int currentPage = 1;

			String pageParam = request.getParameter("page");
			if (pageParam != null && pageParam.matches("\\d+")) {
				currentPage = Integer.parseInt(pageParam);
			}

			int totalPages = (listaCuentas.size() + pageSize - 1) / pageSize;

			if (currentPage < 1) {
				currentPage = 1;
			} else if (currentPage > totalPages) {
				currentPage = totalPages;
			}

			System.out.println("currentPage: " + currentPage);
			System.out.println("totalPages: " + totalPages);
			System.out.println("listaCuentas size: " + listaCuentas.size());

			int startIdx = (currentPage - 1) * pageSize;
			int endIdx = Math.min(startIdx + pageSize, listaCuentas.size());

			System.out.println("startIdx: " + startIdx);
			System.out.println("endIdx: " + endIdx);

			// sublista para la p�gina actual
			List<Cuenta> listaPaginada = new ArrayList<>();
			if (startIdx >= 0 && startIdx < listaCuentas.size()) {
				listaPaginada = listaCuentas.subList(startIdx, endIdx);
			}

			System.out.println("Tama�o de listaPaginada despu�s de paginaci�n: " + listaPaginada.size());

			request.setAttribute("listaCuentas", listaPaginada);
			request.setAttribute("currentPage", currentPage);
			request.setAttribute("totalPages", totalPages);

			
			request.getRequestDispatcher("BajaCuenta.jsp").forward(request, response);
		}


	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String pagina = request.getParameter("pagina");
		request.setAttribute("error", pagina);

		
		if (request.getParameter("btnBuscarCBU") != null) {

			String CBU = request.getParameter("CBUCuenta");
			if (!CBU.isEmpty()) {

				CuentaNegocio cuentaNegocio = new CuentaNegocio();
				Cuenta cuenta = cuentaNegocio.obtenerCuentaXNroCbu(CBU);

				if (cuenta != null) {
					if (cuenta.getActiva() == true) {
						request.setAttribute("cuenta", cuenta);
						request.getRequestDispatcher("BajaCuenta.jsp").forward(request, response);
					} else {
						String msjError = "La cuenta ya se encuentra dada de baja.";
						request.setAttribute("msjError", msjError);

						request.getRequestDispatcher("Error.jsp").forward(request, response);

					}
				} else {
					String msjError = "No hay un cuenta con ese CBU";
					request.setAttribute("msjError", msjError);

					request.getRequestDispatcher("Error.jsp").forward(request, response);

				}

			} else {
				request.setAttribute("cbuVacio", true);
				request.getRequestDispatcher("BajaCuenta.jsp").forward(request, response);

				return;

			}
		}

		if (request.getParameter("btnDarBajaCuenta") != null) {

			CuentaNegocio cuentaNegocio = new CuentaNegocio();

			String cbuCuenta = request.getParameter("CBUSeleccionado");
			Cuenta cuenaAbajar = cuentaNegocio.obtenerCuentaXNroCbu(cbuCuenta);
			request.setAttribute("cuenaAbajar", cuenaAbajar);

			request.getRequestDispatcher("BajaCuentaConfirmar.jsp").forward(request, response);
		}

		if (request.getParameter("btnConfirmarBaja") != null) {
			System.out.println("btnaceptarbajacuenta");
			
		}
		if (request.getParameter("btnCancelar") != null) {
			request.getRequestDispatcher("BajaCuenta.jsp").forward(request, response);
		}

	}
}
