package servlet;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.ClienteDaoImpl;
import dao.CuentaDao;
import dao.CuentaDaoImpl;
import dominio.Cliente;
import dominio.Cuenta;
import dominio.TipoCuenta;
import negocio.ClienteNegocio;
import negocio.CuentaNegocio;
import negocio.TipoCuentaNegocio;

import java.util.List;

/**
 * Servlet implementation class serveltCuentas
 */
@WebServlet("/servletCuentas")
public class servletCuentas extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public servletCuentas() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		if (request.getParameter("btnListarCuentas") != null) {
			CuentaNegocio cuentaNegocio1 = new CuentaNegocio();

			ArrayList<Cuenta> listaCuentas = (ArrayList<Cuenta>) cuentaNegocio1.listarCuentas();
			System.out.println(listaCuentas.toString());

			int pageSize = 10;
			int currentPage = 1;

			String pageParam = request.getParameter("page");
			if (pageParam != null && pageParam.matches("\\d+")) {
				currentPage = Integer.parseInt(pageParam);
			}

			int totalPages = (listaCuentas.size() + pageSize - 1) / pageSize;

			if (currentPage < 1) {
				currentPage = 1;
			} else if (currentPage > totalPages) {
				currentPage = totalPages;
			}

			System.out.println("currentPage: " + currentPage);
			System.out.println("totalPages: " + totalPages);
			System.out.println("listaCuentas size: " + listaCuentas.size());

			int startIdx = (currentPage - 1) * pageSize;
			int endIdx = Math.min(startIdx + pageSize, listaCuentas.size());

			System.out.println("startIdx: " + startIdx);
			System.out.println("endIdx: " + endIdx);

			// sublista para la p�gina actual
			List<Cuenta> listaPaginada = new ArrayList<>();
			if (startIdx >= 0 && startIdx < listaCuentas.size()) {
				listaPaginada = listaCuentas.subList(startIdx, endIdx);
			}

			System.out.println("Tama�o de listaPaginada despu�s de paginaci�n: " + listaPaginada.size());

			request.setAttribute("listaCuentas", listaPaginada);
			request.setAttribute("currentPage", currentPage);
			request.setAttribute("totalPages", totalPages);

			/* Log de eroores en java - sacar NICO */
			// System.out.println("Valor de page en el Servlet: " + currentPage);
			// System.out.println("URL completa en el Servlet: " + request.getRequestURL() +
			// "?" + request.getQueryString());
			// System.out.println("Valor de page en el Servlet: " +
			// request.getParameter("page"));
			request.getRequestDispatcher("ListadoCuentas.jsp").forward(request, response);
		}

		/*----------------------------------------------------------------------------*/

		if (request.getAttribute("clienteLogueado") != null) {

			CuentaNegocio cuentaNegocio = new CuentaNegocio();
			Cliente clienteLogueado = new Cliente();
			clienteLogueado = (Cliente) request.getAttribute("clienteLogueado");
			List<Cuenta> listaCuentas = new ArrayList<Cuenta>();
			listaCuentas = (ArrayList<dominio.Cuenta>) cuentaNegocio.listaCuentaXdni(clienteLogueado.getDni());
			request.setAttribute("cuentasClienteLogueado", listaCuentas);
		}

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		
		String pagina = request.getParameter("pagina");
		request.setAttribute("error", pagina);

		if (request.getParameter("btnBuscarCuentas") != null) {

			CuentaNegocio cuentaNegocio2 = new CuentaNegocio();
			String dni = request.getParameter("dniClientCuentaBuscar");
			if (!dni.isEmpty()) {
			List<Cuenta> cuentaEncontrada = cuentaNegocio2.listaCuentaXdni(dni);

			if (cuentaEncontrada != null && !cuentaEncontrada.isEmpty()) {
				int itemsPerPage = 10;
				int currentPage = 1;

				String pageParam = request.getParameter("page");
				if (pageParam != null && !pageParam.isEmpty()) {
					try {
						currentPage = Integer.parseInt(pageParam);
					} catch (NumberFormatException e) {
						e.printStackTrace();
					}
				}

				int startIdx = (currentPage - 1) * itemsPerPage;
				int endIdx = Math.min(startIdx + itemsPerPage, cuentaEncontrada.size());

				List<Cuenta> listaPaginada = cuentaEncontrada.subList(startIdx, endIdx);

				request.setAttribute("listaCuentas", listaPaginada);
				request.setAttribute("currentPage", currentPage);
				request.setAttribute("totalPages", (int) Math.ceil((double) cuentaEncontrada.size() / itemsPerPage));

				request.getRequestDispatcher("ListadoCuentas.jsp").forward(request, response);
			} else {
				String msjError = "No hay un usuario con ese Dni";
				request.setAttribute("msjError", msjError);

				request.getRequestDispatcher("Error.jsp").forward(request, response);
				
			}
			}
			else
			{
				request.setAttribute("dniVacio", true);
				request.getRequestDispatcher("ListadoCuentas.jsp").forward(request, response);

				return;
				
			}
		}

		if (request.getParameter("validarDni") != null) {
			String dniCuenta = request.getParameter("dniCuenta");
			
			ClienteNegocio clienteNegocio = new ClienteNegocio();
			Cliente cliente = clienteNegocio.obtenerCliente(dniCuenta);
			if (cliente!=null && cliente.getActivo()) {
			System.out.println (cliente.toString());
			
			String CBU = request.getParameter("CBU");
			cliente.setCbu(CBU);

			request.setAttribute("cliente", cliente);
			TipoCuentaNegocio tipoCuentaNegocio = new TipoCuentaNegocio();
			List<TipoCuenta> tiposCuenta = tipoCuentaNegocio.ListartiposCuenta();
			System.out.println("Tipos de cuenta: " + tiposCuenta);
			request.setAttribute("tiposCuenta", tiposCuenta);

			request.getRequestDispatcher("Cuentas.jsp").forward(request, response);

			clienteNegocio.actualizar(cliente, dniCuenta);
			}
			else
			{
				
				System.out.println("pagina de servletcuentas" + pagina);
				String msjError = "No hay un usuario con ese Dni";
				request.setAttribute("msjError", msjError);

				request.getRequestDispatcher("Error.jsp").forward(request, response);
			}
		}
		if (request.getParameter("btnAceptarCuentaNueva") != null) {
		    request.getRequestDispatcher("Cuentas.jsp").forward(request, response);
		}


		if (request.getParameter("btnCrearCuenta") != null) {

			String dniCuenta = request.getParameter("dniCuenta");

			ClienteNegocio clienteNegocio = new ClienteNegocio();
			Cliente cliente = clienteNegocio.obtenerCliente(dniCuenta);

			
			
			CuentaNegocio cuentaNegocio = new CuentaNegocio();

			int cantidadCuentas = cuentaNegocio.cantidadCuentasNegocio(cliente);
			
			if (cantidadCuentas < 3) {
				TipoCuentaNegocio tipoCuentaNegocio = new TipoCuentaNegocio();

				String tipoCuentaSeleccionadaStr = request.getParameter("TipoCuenta");

				TipoCuenta tipoCuenta = tipoCuentaNegocio.obtenerTipoCuentaXNombre(tipoCuentaSeleccionadaStr);
				System.out.println("Tipo de cuenta seleccionado: " + tipoCuenta);

				Date fechaActual = new Date();

				SimpleDateFormat formatoFecha = new SimpleDateFormat("yyyy-MM-dd");
				String FechaCreacion = formatoFecha.format(fechaActual);

				Boolean Activa = true;

				Cuenta Cuenta = new Cuenta(cliente, tipoCuenta, FechaCreacion, Activa);
				String NroCuenta = Cuenta.getNroCuenta();

				request.setAttribute("Cuenta", Cuenta);

				// Redireccionar a
				RequestDispatcher dispatcher = request.getRequestDispatcher("CuentaNueva.jsp");
				dispatcher.forward(request, response);
				System.out.println(Cuenta.toString());

				boolean exito = cuentaNegocio.crearCuenta(Cuenta);
				System.out.println("M�todo insert llamado, �xito: " + exito);
			}
			else
			{
				request.setAttribute("TresCuentas", true);
				request.getRequestDispatcher("Cuentas.jsp").forward(request,response);

			}
		}

	}

}
