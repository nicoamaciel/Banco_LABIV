package servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dominio.Cuenta;
import negocio.CuentaNegocio;

/**
 * Servlet implementation class servletLogin
 */
@WebServlet("/servletError")
public class servletError extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public servletError() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

	
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		if (request.getParameter("btnVolverLoge") != null) {
			String redirectURL = request.getParameter("paginaAnterior");

			if (redirectURL != null) {
				request.getRequestDispatcher(redirectURL).forward(request, response);
			} else {
				// Manejar el caso cuando "paginaAnterior" es null
				// Puedes redirigir a una p�gina de error o realizar alguna acci�n espec�fica.
				response.getWriter().println("Error: La p�gina anterior no est� especificada.");
			}

		}
	}

}