
package servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dominio.Cuenta;
import negocio.CuentaNegocio;

/**
 * Servlet implementation class servletMisCuentas
 */

@WebServlet("/servletMisCuentas")
public class servletMisCuentas extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public servletMisCuentas() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// Obtener el par�metro 'usuario' de la URL
        
		
		String usuario = request.getParameter("usuario");
        String redirectURL = request.getParameter("pagina");
        CuentaNegocio cntNeg = new CuentaNegocio();
      
        
        
        List<Cuenta> listado = new ArrayList<Cuenta>();
        listado = cntNeg.obtenerCuentaXemail(usuario);
        
        
        request.setAttribute("listado", listado);
        
   
        request.getRequestDispatcher(redirectURL).forward(request, response);
    }
		
    
	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		
        
	}

}
