package servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.MovimientoDaoImpl;
import dominio.Cuenta;
import dominio.Movimiento;
import negocio.CuentaNegocio;
import negocio.MovimientoNegocio;

/**
 * Servlet implementation class servletMisCuentas
 */
@WebServlet("/servletMovimientos")
public class servletMovimientos extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public servletMovimientos() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String nroCuenta = request.getParameter("NroCuenta");
	    System.out.println("N�mero de cuenta recibido: " + nroCuenta);

	    if (nroCuenta != null) {
	        MovimientoNegocio movNegocio = new MovimientoNegocio();
	        List<Movimiento> listaMovimiento = movNegocio.listarMovimientosXNroCuenta(nroCuenta);

	        System.out.println("Lista de movimientos: " + listaMovimiento);

	        request.setAttribute("listaMovimiento", listaMovimiento);
	        request.getRequestDispatcher("Movimientos.jsp").forward(request, response);
	    } else {
	        System.out.println("Par�metro 'NroCuenta' es nulo.");
	    }

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		if (request.getParameter("NroCuenta") != null) {
			String nroCuenta = request.getParameter("NroCuenta");

			if (nroCuenta != null) {
				MovimientoNegocio movNegocio = new MovimientoNegocio();
				List<Movimiento> listaMovimiento = movNegocio.listarMovimientosXNroCuenta(nroCuenta);
				
				request.setAttribute("listaMovimiento", listaMovimiento);
				request.getRequestDispatcher("Movimientos.jsp").forward(request, response);
			}

		}

	}
}