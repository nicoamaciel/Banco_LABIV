package servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dominio.CuotasPrestamos;
import dominio.Prestamo;
import negocio.CuentaNegocio;
import negocio.CuotasPrestamosNegocio;
import negocio.MovimientoNegocio;
import negocio.PrestamoNegocio;

/**
 * Servlet implementation class servletPagarPrestamo
 */
@WebServlet("/servletPagarPrestamo")
public class servletPagarPrestamo extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public servletPagarPrestamo() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 
		
		CuotasPrestamosNegocio prestamoNegocio = new CuotasPrestamosNegocio();
		
		
		
		if (request.getParameter("btnListarPrestamos") != null) {
			        	 
        	 
			 String usuario = request.getParameter("usuario");
			
			 System.out.println("USUARIO: "+ usuario);
			 
			 
		             List<CuotasPrestamos> listaCompleta = prestamoNegocio.obtenerPrestamos(usuario);
		             System.out.println("lista: "+ listaCompleta);
		             
		             
		             
		             request.setAttribute("listaPrestamo", listaCompleta);


             request.getRequestDispatcher("PagarPrestamo.jsp").forward(request, response);
         }
		
		if(request.getParameter("btnPagarPrestamo") != null) {
			
			String idPrestamoSeleccionado = request.getParameter("radioIdPrestamo");
			
			
			if (idPrestamoSeleccionado != null) {
		       
				MovimientoNegocio movimientoNegocio= new MovimientoNegocio();
		        CuotasPrestamos cuotasPrestamos= new CuotasPrestamos();
		        
		        
		       CuotasPrestamosNegocio cuotasPrestamosNegocio=new CuotasPrestamosNegocio();
		        

		        
		        cuotasPrestamos= prestamoNegocio.traerPrestamo(Integer.parseInt(idPrestamoSeleccionado));
		        
		        System.out.println("CUOTAS PRESTAMOS; " + cuotasPrestamos);
		        
		        boolean resultadoSumarCuota  = prestamoNegocio.sumarCuotaPagada(cuotasPrestamos.getIdCuota());
		        
		        
		        cuotasPrestamos= cuotasPrestamosNegocio.traerPrestamoxId(idPrestamoSeleccionado);

		        
		        boolean resultMovNegativoPago    = movimientoNegocio.crearMovimientoPago(cuotasPrestamos);
		        
		        
		        
		        boolean resultDescontarCuenta    = CuentaNegocio.descontarDeCuenta(cuotasPrestamos);
		        
		        
		        System.out.println("Resultado sumar " + resultadoSumarCuota);
		        System.out.println("Resultado sumar " + resultMovNegativoPago);
		        System.out.println("Resultado sumar " + resultDescontarCuenta);
		        
		        request.getRequestDispatcher("pagoCuotaExito.jsp").forward(request, response);
		       
		    } else {
		        
		        System.out.println(" prestamo");
		    }
			
		}
			
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
