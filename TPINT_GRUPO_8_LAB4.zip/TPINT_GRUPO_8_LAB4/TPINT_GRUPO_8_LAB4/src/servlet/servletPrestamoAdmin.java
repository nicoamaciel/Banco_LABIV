package servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dominio.Cliente;
import dominio.Movimiento;
import dominio.Prestamo;
import negocio.ClienteNegocio;
import negocio.MovimientoNegocio;
import negocio.PrestamoNegocio;

/**
 * Servlet implementation class servletPrestamoAdmin
 */
@WebServlet("/servletPrestamoAdmin")
public class servletPrestamoAdmin extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public servletPrestamoAdmin() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		System.out.println("Se ha invocado el m�todo doGet en servletPrestamoAdmin");

		PrestamoNegocio prestamoNegocio = new PrestamoNegocio();

		if (request.getParameter("btnMostrarPrestamos") != null) {
			System.out.println("Bot�n 'Mostrar pr�stamos' presionado");

			List<Prestamo> listaCompleta = prestamoNegocio.obtenerPrestamos();
			System.out.println("lista: " + listaCompleta);
			request.setAttribute("listaPrestamo", listaCompleta);

			request.getRequestDispatcher("ListadoPrestamos.jsp").forward(request, response);
		}

		if (request.getParameter("btnNegar") != null) {
			MovimientoNegocio movimientoNegocio = new MovimientoNegocio();

			String[] prestamosSeleccionados = request.getParameterValues("prestamoId[]");

			if (prestamosSeleccionados != null && prestamosSeleccionados.length > 0) {
				List<Movimiento> prestamosAprobar = new ArrayList<>();
				for (String prestamoId : prestamosSeleccionados) {

					System.out.println("ID: " + prestamoId);

					int id = Integer.parseInt(prestamoId);
					boolean negarPrestamo = movimientoNegocio.negarPrestamo(id);

					if (negarPrestamo) {
						System.out.println("se borro el prestamo");
					}

				}

			}
			List<Prestamo> listaCompleta = prestamoNegocio.obtenerPrestamos();
			request.setAttribute("listaPrestamo", listaCompleta);
			request.getRequestDispatcher("ListadoPrestamos.jsp").forward(request, response);

		}

		if (request.getParameter("btnAprobar") != null) {
			MovimientoNegocio movimientoNegocio = new MovimientoNegocio();

			String[] prestamosSeleccionados = request.getParameterValues("prestamoId[]");

			if (prestamosSeleccionados != null && prestamosSeleccionados.length > 0) {
				List<Movimiento> prestamosAprobar = new ArrayList<>();
				for (String prestamoId : prestamosSeleccionados) {

					System.out.println("ID: " + prestamoId);

					int id = Integer.parseInt(prestamoId);
					Movimiento movimiento = movimientoNegocio.obtenerPrestamoPorId(id);

					if (movimiento != null) {
						prestamosAprobar.add(movimiento);
					}
				}

				for (Movimiento prestamo : prestamosAprobar) {
					movimientoNegocio.aprobarPrestamo(prestamo);
				}
			}

			// Volver a cargar la lista de pr�stamos y mostrar la p�gina
			List<Prestamo> listaCompleta = prestamoNegocio.obtenerPrestamos();
			request.setAttribute("listaPrestamo", listaCompleta);
			request.getRequestDispatcher("ListadoPrestamos.jsp").forward(request, response);

		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String pagina = request.getParameter("pagina");
		request.setAttribute("error", pagina);

		if (request.getParameter("btnBuscarXdni") != null) {

			String dniBuscar = request.getParameter("dniBuscar");

			if (!dniBuscar.isEmpty()) {

				PrestamoNegocio prestamoNegocio = new PrestamoNegocio();
				Cliente cliente = new Cliente();
				ClienteNegocio clienteNegocio = new ClienteNegocio();

				cliente = clienteNegocio.obtenerCliente(dniBuscar);
				if (cliente != null) {

					List<Prestamo> prestamosPorDni = prestamoNegocio.obtenerPrestamosXdni(dniBuscar);
					if (prestamosPorDni != null) {
						request.setAttribute("listaPrestamo", prestamosPorDni);

						request.getRequestDispatcher("ListadoPrestamos.jsp").forward(request, response);
					} else {
						String msjError = "El cliente no tiene prestamos soliticados esperando autorizacion";
						request.setAttribute("msjError", msjError);

						request.getRequestDispatcher("Error.jsp").forward(request, response);

					}
				} else {
					String msjError = "No hay un usuario con ese Dni";
					request.setAttribute("msjError", msjError);

					request.getRequestDispatcher("Error.jsp").forward(request, response);

				}
			} else {
				request.setAttribute("dniVacio", true);
				request.getRequestDispatcher("ListadoPrestamos.jsp").forward(request, response);

				return;

			}

		}
	}
}
