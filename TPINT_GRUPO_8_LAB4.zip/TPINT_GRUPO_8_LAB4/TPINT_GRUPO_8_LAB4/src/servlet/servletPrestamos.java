package servlet;

import java.io.IOException;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.ClienteDaoImpl;
import dominio.Cliente;
import dominio.Cuenta;
import dominio.CuotasPrestamos;
import dominio.Movimiento;
import dominio.TipoMovimiento;
import negocio.ClienteNegocio;
import negocio.CuentaNegocio;
import negocio.MovimientoNegocio;
import negocio.TipoMovimientoNegocio;
import negocio.CuotasPrestamosNegocio;
import dao.CuotasPrestamosDao;
import dao.CuotasPrestamosDaoImpl;



/**
 * Servlet implementation class servletPrestamos
 */
@WebServlet("/servletPrestamos")
public class servletPrestamos extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public servletPrestamos() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// Obtener el par�metro 'usuario' de la URL
        String usuario = request.getParameter("usuario");

        ClienteNegocio clntNeg = new ClienteNegocio();
		
        Cliente user = new Cliente();
        user  = clntNeg.buscarXusuario(usuario);
        
        
		
		CuentaNegocio cntNeg = new CuentaNegocio();
		
        List<Cuenta> listado = new ArrayList<Cuenta>();
        listado = cntNeg.listaCuentaXdni(user.getDni());
       
        request.setAttribute("user", user);
        request.setAttribute("listado", listado);
        request.getRequestDispatcher("Prestamos.jsp").forward(request, response);
        
        
        
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	    
	    if (request.getParameter("btnSolicitudPrestamo") != null) {
	        HttpSession session = request.getSession();
	        String usuario = (String) session.getAttribute("usuario");

	        ClienteNegocio clntNeg = new ClienteNegocio();

	        Cliente user = new Cliente();
	        user = clntNeg.buscarXusuario(usuario);
	        CuentaNegocio cntNeg2 = new CuentaNegocio();
	        Cuenta cuentaUsuario = cntNeg2.obtenerCuentaXDni(user.getDni());

	        String montoStr = request.getParameter("MontoPrestamo");
	        String cuotasStr = request.getParameter("cuotas");

	        // Convertir los valores a n�meros
	        try {
	            double monto = Double.parseDouble(montoStr);
	            int cuotas = Integer.parseInt(cuotasStr);

	            String nroCuentaStr = cuentaUsuario.getNroCuenta();

	            request.setAttribute("monto", monto);
	            request.setAttribute("cuotas", cuotas);

	            Date fechaActual = new Date();

	            SimpleDateFormat formatoFecha = new SimpleDateFormat("yyyy-MM-dd");
	            String fechaCreacion = formatoFecha.format(fechaActual);

	            String detalle = "Prestamo: " + user.getEmail();
	            boolean activa = false;
	            TipoMovimiento tipoMovimiento = new TipoMovimiento();
	            tipoMovimiento.setId(2);
	            TipoMovimientoNegocio tipomovnegocio = new TipoMovimientoNegocio();
	            tipoMovimiento = tipomovnegocio.obtenerTipoMovimientoXId(tipoMovimiento.getId());

	            Movimiento movimiento = new Movimiento(nroCuentaStr, detalle, fechaCreacion, monto, tipoMovimiento, cuotas, activa);

	            MovimientoNegocio movNeg = new MovimientoNegocio();
	            boolean prestamo = movNeg.crearMovimiento(movimiento);

	            
	            double interes = 1.0;
	            if (cuotas == 12) {
	                interes = 1.2;
	            } else if (cuotas == 24) {
	                interes = 1.5;
	            } else if (cuotas == 36) {
	                interes = 1.8;
	            }

	            //  cuotas fijas
	            double cuotaFija = monto / cuotas;

	            // importes con intereses
	            double finalConInteres = monto * interes;

	            //  cuotas con intereses
	            double montoCuotaConInteres = cuotaFija * interes;

	            // Estado en false para aprobaci�n 
	            boolean estadoCuota = false;

	            CuotasPrestamos cuotaPrestamo = new CuotasPrestamos(nroCuentaStr, cuotas, monto, interes, cuotaFija,
	                    finalConInteres, montoCuotaConInteres, estadoCuota);

	            CuotasPrestamosNegocio cuoNeg = new CuotasPrestamosNegocio();
	            boolean cargarCuota = cuoNeg.crearCuotasPrestamo(cuotaPrestamo);

	           

	            if (prestamo && cargarCuota) {
	                response.sendRedirect("PrestamoExito.jsp");
	            } else {
	                response.sendRedirect("Error.jsp");
	            }
	        } catch (NumberFormatException | NullPointerException e) {
	          
	            response.getWriter().println("Ocurri� un error al procesar la solicitud.");
	            e.printStackTrace(response.getWriter());
	        }
	    } else if (request.getParameter("btnPagarPrestamo") != null) {
	        request.getRequestDispatcher("PagarPrestamo.jsp").forward(request, response);
	    }
	}
	
}