package servlet;

import java.util.List;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.ClienteDaoImpl;
import dominio.Cliente;
import dominio.Cuenta;
import dominio.Movimiento;
import dominio.TipoMovimiento;
import negocio.ClienteNegocio;
import negocio.CuentaNegocio;
import negocio.MovimientoNegocio;
import negocio.TipoMovimientoNegocio;

@WebServlet("/servletTransferencia")
public class servletTransferencia extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @return
	 * @see HttpServlet#HttpServlet()
	 */
	public void servletCliente() {

		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		if (request.getParameter("btnTransferenciaExitosa") != null) {

			request.getRequestDispatcher("MenuCliente.jsp").forward(request, response);

		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		if (request.getParameter("btnTransferencias") != null) {

			String pagina = request.getParameter("pagina");
			request.setAttribute("error", pagina);

			// Se establece monto a transferir
			String montoTransferir = request.getParameter("montoTransferencia");
			request.setAttribute("montoTransferir", montoTransferir);
			double monto = Double.parseDouble(montoTransferir);
			if (monto > 0) {
				CuentaNegocio negocioCuenta = new CuentaNegocio();

				// Se establece cuenta de origen
				String cuenta = request.getParameter("cuentaOrigen");
				Cuenta cuentaOrigen = negocioCuenta.obtenerCuentaXNroCuenta(cuenta);
				if (monto < cuentaOrigen.getSaldo()) {
					negocioCuenta.debitarImporte(cuentaOrigen.getNroCuenta(), monto);

					// Se establece cuenta de destino
					String destino = null;
					Cuenta cuentaDestino = new Cuenta();
					destino = request.getParameter("cuentaDestino");
					if (destino != null) {
						cuentaDestino = negocioCuenta.obtenerCuentaXNroCuenta(destino);
					} else {
						destino = request.getParameter("cuentaDestinoTerceros");

						cuentaDestino = negocioCuenta.obtenerCuentaXNroCbu(destino);

					}

					if (cuentaDestino != null) {
						negocioCuenta.acreditarImporte(cuentaDestino.getNroCuenta(), monto);

							
						Date fechaActual = new Date();
					        
					    SimpleDateFormat formatoFecha = new SimpleDateFormat("yyyy-MM-dd");
					    String fecha = formatoFecha.format(fechaActual);
						

						String detalle = null;
						detalle = ("Transferencia enviada a Dni: " + cuentaDestino.getCliente().getDni());
						
						boolean Activa = true;
						TipoMovimiento tipoMovimiento = new TipoMovimiento();
						tipoMovimiento.setId(1);
						TipoMovimientoNegocio tipoMov = new TipoMovimientoNegocio();
						
						tipoMovimiento = tipoMov.obtenerTipoMovimientoXId(tipoMovimiento.getId());
						Movimiento movimientoDebitar = new Movimiento(cuentaOrigen.getNroCuenta(), detalle, fecha,
								monto, tipoMovimiento, Activa);
						
						detalle = ("Transferencia recibida de Dni: "+ cuentaOrigen.getCliente().getDni());
						Movimiento movimientoAcreditar = new Movimiento(cuentaDestino.getNroCuenta(), detalle, fecha,
								monto, tipoMovimiento, Activa);

						MovimientoNegocio negocioMovimiento = new MovimientoNegocio();

						boolean debitoExitoso = negocioMovimiento.crearTransferencia(movimientoDebitar);
						boolean creditoExitoso = negocioMovimiento.crearTransferencia(movimientoAcreditar);

						if (debitoExitoso && creditoExitoso) {
							request.getRequestDispatcher("TransferenciaExitosa.jsp").forward(request, response);

						} else {
							String msjError = "Hubo un problema con la transaccion";
							request.setAttribute("msjError", msjError);

							request.getRequestDispatcher("Error.jsp").forward(request, response);
						}
					} else {
						String msjError = "La cuenta destino no existe";
						request.setAttribute("msjError", msjError);

						request.getRequestDispatcher("Error.jsp").forward(request, response);
					}

				} else {
					String msjError = "No cuenta con saldo suficiente para la transferencia";
					request.setAttribute("msjError", msjError);

					request.getRequestDispatcher("Error.jsp").forward(request, response);
				}
			} else {
				String msjError = "El monto a transferir debe ser mayor a 0";
				request.setAttribute("msjError", msjError);

				request.getRequestDispatcher("Error.jsp").forward(request, response);
			}
		}
	}
}
